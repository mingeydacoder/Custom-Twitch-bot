from twitchio.ext import commands
from dataclasses import dataclass
#import keep_alive
import json
import requests
import random
import time 
import sqlite3
from datetime import datetime, timedelta
import asyncio
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import pygsheets



def make_request(url):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Check if the request was successful
        return response.json()  # Return the JSON response
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")  # Print HTTP error
    except Exception as err:
        print(f"Other error occurred: {err}")  # Print any other error

def rank():
    apikey = 'RGAPI-fa134c9f-770a-464c-94a7-b61e47b84d3e'
    url = f"https://kr.api.riotgames.com/lol/league/v4/entries/by-summoner/tr835MMdj1ZWBhegcGXjiCk4cU2c5GXGMRJXo3p3px9Rdso?api_key={apikey}"  # Replace with your request URL
    result = make_request(url)
    
    if result:
        print("Request was successful.")
        print("Response:")
        #print(result)
        return(result[0]['tier'],result[0]['leaguePoints'],result[0]['wins'],result[0]['losses'])
    else:
        print("Failed to retrieve data.")

@dataclass
class MessageData:
    author: str
    content: str
    channel: str
    is_mod: bool

class Bot(commands.Bot):

    def __init__(self):
        # Initialise our Bot with our access token, prefix and a list of channels to join on boot...
        # prefix can be a callable, which returns a list of strings or a string...
        # initial_channels can also be a callable which returns a list of strings...
        super().__init__(token='mloiry6jiupz7qrzfzwii5l1kzr46g', prefix='!', initial_channels=['lav3nd3rtree'])
        self.author_names = []
        self.last_announcement_time = 0
        self.cooldown_period = 30  # Cooldown period in seconds

        self.mode_on = False  # 模式的狀態開關
        self.mode_task = None  # 用來存放非同步任務
        
        # 建立或連接 SQLite 資料庫
        self.conn = sqlite3.connect('global_cooldown.db')
        self.cursor = self.conn.cursor()
        # 建立資料表，儲存命令的全局冷卻時間
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS global_cooldown (
                command_name TEXT,
                last_used REAL,
                PRIMARY KEY (command_name)
            )
        ''')
        self.conn.commit()
        
    def check_and_update_cooldown(self, command_name: str, cooldown: int):
        """
        檢查冷卻時間是否已過，並更新冷卻時間。
        :param command_name: 指令名稱
        :param cooldown: 冷卻時間（秒）
        :return: 剩餘冷卻時間（如果冷卻中）或 None
        """
        current_time = time.time()
        self.cursor.execute('SELECT last_used FROM global_cooldown WHERE command_name = ?', (command_name,))
        result = self.cursor.fetchone()

        if result:
            last_used = result[0]
            if current_time - last_used < cooldown:
                return cooldown - (current_time - last_used)

        # 更新冷卻時間
        self.cursor.execute('''
            INSERT INTO global_cooldown (command_name, last_used)
            VALUES (?, ?)
            ON CONFLICT(command_name) DO UPDATE SET last_used = excluded.last_used
        ''', (command_name, current_time))
        self.conn.commit()
        return None

    async def event_ready(self):
        # Notify us when everything is ready!
        # We are logged in and ready to chat and use commands...
        print(f'Logged in as | {self.nick}')
        print(f'User id is | {self.user_id}')

    async def event_message(self, message):
        # Messages with echo set to True are messages sent by the bot...
        # For now we just want to ignore them...
        if message.echo:
            return
    
        
        # Check if the user is a moderator
        is_mod = message.author.is_mod

        # Print the contents of our message to console...
        print(message.content)

        if message.content.lower() == 'hello':
            await bot.connected_channels[0].send('Hello there! 👋')
        
        def chat_announcement(self):
            current_time = time.time()
            if current_time - self.last_announcement_time < self.cooldown_period:
                return
        
            url = 'https://api.twitch.tv/helix/chat/announcements'
            params = {
                'broadcaster_id': '653847938',
                'moderator_id': '1092759858'
            }
            headers = {
                'Authorization': 'Bearer mloiry6jiupz7qrzfzwii5l1kzr46g',
                'Client-Id': 'gp762nuuoqcoxypju8c569th9wz7q5',
                'Content-Type': 'application/json'
            }
            data = {
                'message': 'imGlitch 本台嚴厲斥責任何形式之惡意言論，聊天室言論及抖內發言皆不代表本台主之立場 ⚠️ ⚠️ ',
                'color': 'purple'
            }

            response = requests.post(url, headers=headers, params=params, json=data)

            if response.status_code == 204:
                print('Announcement sent successfully!')
                self.last_announcement_time = time.time()
                return(response)
            else:
                print(f'Failed to reply announcement: {response.status_code}')
                print(response.json())
                
        if message.content == "嚴厲斥責":
            chat_announcement(self)


            
        #print(self.author_names)
        print(f"Is Mod: {is_mod}")

        self.author_names.append(message.author.name)

        def timeout(id):
            broadcaster_id = "653847938"  
            moderator_id = "1092759858"  
            user_id = id
            duration = 600 
            reason = "Potential spamming (excuted by lavendertree's bot)" 

            headers = {
                "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
                "Authorization": "Bearer mloiry6jiupz7qrzfzwii5l1kzr46g",
                "Content-Type": "application/json"
            }

            url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

            json_data = {
            'data': {
                'user_id': user_id,
                'duration': duration,  
                'reason': reason  
                }
            }
            json_payload = json.dumps(json_data)
            response = requests.post(url, headers=headers, data=json_payload)



        def check_if_live(username):
            try:
                response = requests.get(f"https://twitch.tv/{username}")
                response.raise_for_status()
                source_code = response.text

                if "isLiveBroadcast" in source_code:
                    return 1
                else:
                    return 0
            except requests.exceptions.RequestException as error:
                print("Error occurred:", error)

        if len(self.author_names) >= 6 and self.author_names[-1] == self.author_names[-2] == self.author_names[-3] and check_if_live("lav3nd3rtree") == 0:
            if message.author.name == 'lav3nd3rtree':
                pass
            elif self.author_names[-1] == self.author_names[-2] == self.author_names[-3] == self.author_names[-4]:
                pass
            elif self.author_names[-1] == self.author_names[-2] == self.author_names[-3] == self.author_names[-4] == self.author_names[-5]:
                pass
            elif self.author_names[-1] == self.author_names[-2] == self.author_names[-3] == self.author_names[-4] == self.author_names[-5] == self.author_names[-6]:
                pass
            elif message.author.is_mod == 1:
                await bot.connected_channels[0].reply(f'@{message.author.name} Mod 帶頭洗頻，壞壞!')
            elif message.author.is_mod == 0:
                await bot.connected_channels[0].reply(f'@{message.author.name} 偵測到三行，請節制發言 🈹 ')
                timeout(message.author.id)



        # Since we have commands and are overriding the default `event_message`
        # We must let the bot know we want to handle and invoke our commands...
        await self.handle_commands(message)
        return message.author.name



    @commands.command()
    async def apex(self, ctx: commands.Context):
        await ctx.reply(f'冠緯Rwei - 頂獵殺手緯神尾圈收掉四名頂獵（左打OWO、右打波靈、上打凱蛇、下打杰倫)  https://www.youtube.com/watch?v=mZNc3zHd-XQ&t=52s&pp=ygUL5Yag57evIGFwZXg%3D')

    @commands.command(name='600')
    async def vanish(self, ctx):
        broadcaster_id = "653847938"  
        moderator_id = "1092759858"  
        user_id = ctx.author.id  
        duration = 600 
        reason = "They wanna timeout themselves" 

        headers = {
            "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
            "Authorization": "Bearer mloiry6jiupz7qrzfzwii5l1kzr46g",
            "Content-Type": "application/json"
        }

        url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

        json_data = {
        'data': {
            'user_id': user_id,
            'duration': duration,  
            'reason': reason  
            }
        }
        json_payload = json.dumps(json_data)
        response = requests.post(url, headers=headers, data=json_payload)

        respond_list = ['想冷靜一下0..0', '覺得刀子很利，自ban了 guanwe1789 ', 'See u in 600 seconds!']
        
        if response.status_code == 200:
            await ctx.reply(f" @{ctx.author.name} {random.choice(respond_list)}")
        else:
            print(response.text)
            await ctx.reply(f" @{ctx.author.name} ban不了你QAQ")

    @commands.command(name='6OO')
    async def vanish2(self, ctx):
        broadcaster_id = "653847938"  
        moderator_id = "1092759858"  
        user_id = ctx.author.id  
        duration = 600 
        reason = "They wanna timeout themselves" 

        headers = {
            "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
            "Authorization": "Bearer mloiry6jiupz7qrzfzwii5l1kzr46g",
            "Content-Type": "application/json"
        }

        url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

        json_data = {
        'data': {
            'user_id': user_id,
            'duration': duration,  
            'reason': reason  
            }
        }
        json_payload = json.dumps(json_data)
        response = requests.post(url, headers=headers, data=json_payload)

        
        if response.status_code == 200:
            await ctx.reply(f" @{ctx.author.name} 以為打OO就不會被ban xdd1ICANT xdd1ICANT ")
        else:
            print(response.text)
            await ctx.reply(f" @{ctx.author.name} ban不了你QAQ")
        

    @commands.command(name='抽')
    async def vanishPOT(self, ctx):
        broadcaster_id = "653847938"  
        moderator_id = "1092759858"  
        user_id = ctx.author.id  

        # 定義禁言時間及其對應的權重
        timeout_options = [10,69, 487, 1212]  # 禁言時間（秒）
        weights = [0.5, 0.25, 0.15, 0.1]  # 對應的機率，加總需為 1

        # 隨機選擇禁言時間
        duration = random.choices(timeout_options, weights)[0]

        reason = "They wanna timeout themselves" 

        headers = {
            "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
            "Authorization": "Bearer mloiry6jiupz7qrzfzwii5l1kzr46g",
            "Content-Type": "application/json"
        }

        url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

        json_data = {
            'data': {
                'user_id': user_id,
                'duration': duration,  
                'reason': reason  
            }
        }
        json_payload = json.dumps(json_data)
        response = requests.post(url, headers=headers, data=json_payload)

        if response.status_code == 200:  # Twitch API 成功回傳狀態
            if duration == 1212:
                await ctx.reply(f"恭喜 @{ctx.author.name} 抽中大獎，禁言1212秒！")
            else:
                pass
        else:
            pass


    @commands.command()
    async def please(self, ctx: commands.Context):
        await ctx.reply(f'懇求的臉🥺🥺🥺🥺🥺')

    @commands.command(name='commands')
    async def cmd(self, ctx: commands.Context):
        await ctx.reply(f' @{ctx.author.name} !apex \n !600 \n !please \n !分數 or !r \n '  )

    @commands.command(name='指令')
    async def cmds(self, ctx: commands.Context):
        await ctx.reply(f' @{ctx.author.name} !apex \n !600 \n !please \n !分數 or !r \n '  )

    @commands.command(name='分數')
    async def points(self, ctx: commands.Context):
        point = rank()
        winrate= "{:.1f}".format(float((point[2]/(point[2]+point[3]))*100))
        output = str(f'Hi! @{ctx.author.name} 阿緯的韓服即時分數 : 三妖精SAY YA#SAYYA:{point[0]} {point[1]}分, 勝率:{winrate}%')
        await ctx.reply(output)

    @commands.command(name='r')
    async def rpoints(self, ctx: commands.Context):
        point = rank()
        winrate= "{:.1f}".format(float((point[2]/(point[2]+point[3]))*100))
        output = str(f'Hi! @{ctx.author.name} 阿緯的韓服即時分數 : 三妖精SAY YA#SAYYA:{point[0]} {point[1]}分, 勝率:{winrate}%')
        await ctx.reply(output)

    @commands.command(name='骰子')
    async def dice(self, ctx: commands.Context):
        def weighted_roll(sides, weights):
            """
            Rolls a weighted die and returns one of the sides based on the specified weights.
            
            :param sides: A list of the sides of the die.
            :param weights: A list of weights corresponding to the probability of each side.
            :return: A side of the die.
            """
            if len(sides) != len(weights):
                raise ValueError("Sides and weights must be of the same length.")
            
            total_weight = sum(weights)
            rnd = random.uniform(0, total_weight)
            upto = 0
            for side, weight in zip(sides, weights):
                if upto + weight >= rnd:
                    return side
                upto += weight

        sides = [1, 2, 3, 4, 5, 6]
        weights = [1, 1, 1, 1, 1, 1]  
        results = weighted_roll(sides, weights)
        output = results
        if ctx.author.is_mod == 1:
            await ctx.reply(f'🎲 骰子丟出...結果為：{output}！')
        elif ctx.author.is_mod == 0:
            await ctx.reply(f'@{ctx.author.name} 需MOD以上之權限以執行此指令')
            
    #運勢指令

    def init_commandsdb():
        conn = sqlite3.connect("commands.db")  # 建立或連接資料庫
        cursor = conn.cursor()
        # 建立表格（如果不存在）
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS command_usage (
            user_id TEXT NOT NULL,
            command_name TEXT NOT NULL,
            last_executed TIMESTAMP NOT NULL,
            PRIMARY KEY (user_id, command_name)
        )
        """)
        conn.commit()
        conn.close()
    
    init_commandsdb()  # 初始化資料庫
    
    
    @commands.command(name='運勢')
    async def fortune(self, ctx: commands.Context):
        
        fort = ['大吉','中吉','小吉','末吉','凶']
        big = ['天時地利人和，萬事皆能順心如意','無論前進還是停下，都能感受到充滿力量的支持','陽光普照，所有事物都在朝著好的方向發展','內外皆和諧，任何挑戰都能輕鬆迎刃而解','運勢鼎盛，一切都能迎來圓滿的結果']
        mid = ['平穩中帶有上升的氣息，耐心耕耘必有回報','雖然不驚艷，但整體局勢令人感到安心愉快','穩中求進，環境雖未達最佳，但仍有光明可循','雲淡風輕，偶有微風助力，適合穩步前進','運勢逐漸好轉，保持節奏即可迎接美好的變化']
        small = ['時有小福降臨，但仍需腳踏實地，持續努力','局勢略顯波動，但整體方向仍是良好的','偶有阻礙，但每個挑戰都帶來新的可能性','運氣尚可，不宜急功近利，穩健是最佳策略','稍縱即逝的小幸運出現，留心細節便能抓住機會']
        tiny = ['運勢偏弱，但保持冷靜與謹慎仍能穩步向前','現階段需要耐心等待，時機尚未完全成熟','環境略有阻礙，但只要適應節奏即可逐漸改善','表面看似平靜，實則潛藏波折，需時刻注意動態','進展緩慢，但細心經營仍有希望看到成果']
        bad = ['風雨交加，需多加防範，避免冒然行動','低潮時期，保持內心的穩定是最重要的','步履維艱，當下宜以謹慎和耐心為先','暗藏危機，需避免過度樂觀，切勿心存僥倖','外部環境不穩，適宜縮減行動，靜待時局明朗']    
        color = ['亮紅','橘紅','橙','陽光黃','黃綠','森林綠','天藍','海洋藍','紫','海藍','黑','白']
        cat = ['SUBprise','guanwe1Mao1','guanwe1Mao2','guanwe1Nerd','guanwe1Gugu','guanwe1Shy','guanwe1Mao','guanwe1GOOD']
        goodto = ['打LOL','告白','翹課','出遊','檢舉世誠','檢舉羅傑','抖內','買樂透','抖影片','用歐付寶說話','嘲笑逼寶']
        notto = ['打LOL','告白','看實況','呼吸','生存','去樓頂放風','低頭看手機','交易股票','交易虛擬貨幣']
    # 檢查是否可以執行指令
        def can_execute_command(user_id, command_name):
            conn = sqlite3.connect("commands.db")
            cursor = conn.cursor()
            
            # 查詢用戶的指令執行時間
            cursor.execute("""
            SELECT last_executed FROM command_usage
            WHERE user_id = ? AND command_name = ?
            """, (user_id, command_name))
            result = cursor.fetchone()
            
            current_time = datetime.now()
            
            if result:
                last_executed = datetime.fromisoformat(result[0])  # 取得上次執行時間
                # 檢查是否已超過一天
                if current_time - last_executed < timedelta(days=0.5):
                    conn.close()
                    return False  # 不允許執行
            
            # 更新或插入執行時間
            cursor.execute("""
            INSERT OR REPLACE INTO command_usage (user_id, command_name, last_executed)
            VALUES (?, ?, ?)
            """, (user_id, command_name, current_time.isoformat()))
            conn.commit()
            conn.close()
            return True  # 允許執行
        
        user_id = ctx.author.name
        command_name = "運勢"
        
        fcat = random.choice(cat)
        fcolor = random.choice(color)
        result_fortune = random.choice(fort)
        fgoodto = random.choice(goodto)
        fnotto = random.choice(notto)
        
        if result_fortune == '大吉':
            name = '大吉'
            result = random.choice(big)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 宜：{fgoodto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
            else:
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 宜：{fgoodto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
        elif result_fortune == '中吉':
            name = '中吉'
            result = random.choice(mid)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 宜：{fgoodto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
            else:
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 宜：{fgoodto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
        elif result_fortune == '小吉':
            name = '小吉'
            result = random.choice(small)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 宜：{fgoodto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
            else:
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 宜：{fgoodto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
        elif result_fortune == '末吉':
            name = '末吉'
            result = random.choice(tiny)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 不宜：{fnotto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
            else:
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 不宜：{fnotto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
        elif result_fortune == '凶':
            name = '凶'
            result = random.choice(bad)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 不宜：{fnotto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
            else:
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 不宜：{fnotto} | 幸運色：{fcolor} | 幸運貓：{fcat}')
        

    @commands.command(name='冠貓塔')
    async def eat(self, ctx: commands.Context): 
        await ctx.reply('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ SUBprise ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ SUBprise SUBprise ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ SUBprise SUBprise SUBprise ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ SUBprise SUBprise SUBprise SUBprise ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ SUBprise SUBprise SUBprise SUBprise SUBprise')

    @commands.command(name='這場有誰')
    async def player(self, ctx: commands.Context):
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.common.by import By
        from selenium.webdriver.chrome.options import Options
        import time

        #await ctx.reply('資料爬取中，請稍候')

        # 設定瀏覽器選項（可選）
        chrome_options = Options()
        chrome_options.add_argument("--headless")  # 無頭模式（不顯示瀏覽器）
        chrome_options.add_argument("--disable-gpu")  # 停用 GPU（適用於特定環境）

        # 設定 ChromeDriver 路徑
        service = Service("C:\chromedriver.exe")  # 替換為你的 chromedriver 路徑

        # 啟動 WebDriver
        driver = webdriver.Chrome(service=service, options=chrome_options)

        # 爬取網站完整 HTML 程式碼
        url = "https://www.deeplol.gg/summoner/kr/%EC%9C%8C%EB%A6%AC%EC%97%84-9919/ingame"  # 將此替換為目標網站 URL

        try:
            driver.get(url)

            # 等待頁面載入完成（可選，適用於動態內容）
            driver.implicitly_wait(10)  # 最多等待 10 秒

            # 模擬滾動頁面，等待所有內容加載
            # 可以根據網站的具體結構進行滾動，這裡設置滾動到底部，並重複直到加載完成
            last_height = driver.execute_script("return document.body.scrollHeight")

            while True:
                # 滾動到底部
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(3)  # 等待頁面加載新的內容
                new_height = driver.execute_script("return document.body.scrollHeight")

                # 如果滾動到底部且頁面高度不再變化，則停止滾動
                if new_height == last_height:
                    break
                last_height = new_height

            # 獲取完整的 HTML 原始碼
            html_content = driver.page_source
            print("成功取得完整網頁原始碼！")

            # 儲存 HTML 到檔案
            with open("ingame.html", "w", encoding="utf-8") as file:
                file.write(html_content)

        finally:
            # 關閉瀏覽器
            driver.quit()


        file_path = "ingame.html"
        search_word = "influ-name"

        with open(file_path, "r", encoding="utf-8") as file:
            content = file.read()

        pro = []
        streamer = []
        blue_team = []
        red_team = []

        # 搜索所有 "藍" 和 "紅" 的位置
        blue_positions = [pos for pos in range(len(content)) if content.startswith("藍", pos)]
        red_positions = [pos for pos in range(len(content)) if content.startswith("紅", pos)]

        # 搜索所有匹配的位置
        matches = [pos for pos in range(len(content)) if content.startswith(search_word, pos)]

        # 根據位置進行分類
        for match in matches:
            # 在整個上下文中找 ">" 和 "<" 的位置
            start2 = content.find(">", match)
            end2 = content.find("<", start2)

            if start2 != -1 and end2 != -1 and start2 < end2:
                result = content[start2 + 1:end2]

                # 確定該位置的隊伍
                nearest_blue = max([pos for pos in blue_positions if pos < match], default=-1)
                nearest_red = max([pos for pos in red_positions if pos < match], default=-1)

                if nearest_blue > nearest_red:
                    blue_team.append(result)  # 屬於藍方
                elif nearest_red > nearest_blue:
                    red_team.append(result)  # 屬於紅方

                # 額外分類到 streamer 或 pro
                if 'strm' in content[match:]:
                    streamer.append(result)
                elif 'pro' in content[match:]:
                    pro.append(result)

            # 顯示結果
            print("Streamer:", streamer)
            print("Pro:", pro)
            print("藍方隊伍:", blue_team)
            print("紅方隊伍:", red_team)

            
        output = " | ".join(blue_team) 
        output2 = " | ".join(red_team) 
        if not output and not output2:
            await ctx.reply(f'@{ctx.author.name} 主播未在遊戲中')
        else:
            await ctx.reply(f'@{ctx.author.name} 藍方：{output} , 紅方：{output2}')
        
    from typing import Optional

    @commands.command(name='玩什麼')
    async def play(self, ctx: commands.Context, category: Optional[str] = None):
        # 設定冷卻時間（秒）
        cooldown = 15  
        remaining_time = self.check_and_update_cooldown('玩什麼', cooldown)

        if remaining_time:
            return

        # 定義不同的選項對應的清單
        categories = {
            "遊戲": [
                "英雄聯盟", "LOL", "League of Legends", "steam只逛不買", "哩跟歐甫咧捐",
                "韓服英雄聯盟", "台服英雄聯盟", "陸服英雄聯盟", "日服英雄聯盟", "poker", "戶外台",
                "魔物獵人", "跑跑", "Apex", "陪玩只看不點", "楓之谷", "瀏覽Live頻道"
            ],
            "食物": [
                "火鍋", "燒烤", "炒飯", "漢堡", "拉麵", "壽司", "沙拉", "炸雞", "牛排",
                "泰式料理", "韓式烤肉", "印度咖哩", "小吃攤", "甜點"
            ],
            # 你可以繼續添加更多分類
        }

        # 根據用戶輸入的分類選擇
        if category and category in categories:
            choices = categories[category]
        else:
            choices = categories["遊戲"]  # 預設為遊戲

        # 隨機選擇一個項目
        selected_item = random.choice(choices)
        output = str(f'@{ctx.author.name} {selected_item} guanwe1Bangbang')
        await ctx.reply(output)


    @commands.command(name='吃什麼')
    async def eat(self, ctx: commands.Context):
        cooldown = 10  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('吃什麼', cooldown)

        if remaining_time:
            await ctx.reply(f"冷卻中，請等待 {remaining_time:.1f} 秒後再試！")
            return

        foods = [
            "牛肉麵", "水餃", "飯糰", "炒飯", "炒麵", "乾麵", "湯麵", "湯餃", "滷肉飯", "雞肉飯", 
            "雞魯飯", "肉羹麵", "魚酥羹麵", "辣炒年糕", "部隊鍋", "手捲", "大醬湯", "韓式起司拉麵", 
            "拉麵", "壽喜燒", "丼飯", "壽司", "火鍋", "燒烤", "海底撈", "義大利麵", "法式料理", 
            "三明治", "便利商店", "地瓜球", "排骨湯", "麥當勞", "肯德基", "漢堡王", "熱炒", 
            "雞排", "麵包", "鍋燒意麵", "烤肉飯", "水果", "沙拉", "餅乾", "自助餐","披薩"
        ]
        cfood = random.choice(foods)
        output = str(f'@{ctx.author.name} {cfood} guanwe1Bangbang')
        await ctx.send(output)

    @commands.command(name='level')
    async def level(self, ctx: commands.Context, user_name: Optional[str] = None):
        import sqlite3

        def get_user_data(user_id=None, user_name=None):
            """获取指定用户的 score、count 和 total"""
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                
                # 根据 user_id 或 user_name 查询用户数据
                if user_id:
                    cursor.execute('SELECT score, count, total FROM users WHERE user_id = ?', (user_id,))
                elif user_name:
                    cursor.execute('SELECT score, count, total FROM users WHERE user_name = ?', (user_name,))
                else:
                    return None, None, None
                
                result = cursor.fetchone()
                if result:
                    score, count, total = result
                    return score, count, total
                else:
                    return None, None, None

        def get_user_rank(user_id=None, user_name=None, excluded_ids=None):
            """计算用户的 total 排名，支持排除指定用户"""
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                
                # 排除特定的用户
                if excluded_ids:
                    query = '''
                        SELECT user_id, total 
                        FROM users 
                        WHERE user_id NOT IN ({}) 
                        ORDER BY total DESC
                    '''.format(','.join(['?'] * len(excluded_ids)))
                    cursor.execute(query, excluded_ids)
                else:
                    cursor.execute('SELECT user_id, total FROM users ORDER BY total DESC')
                
                all_users = cursor.fetchall()
                
                # 查找用户排名
                for rank, (u_id, total) in enumerate(all_users, start=1):
                    if user_id and u_id == user_id:
                        return rank, total
                    elif user_name:
                        cursor.execute('SELECT user_id FROM users WHERE user_name = ?', (user_name,))
                        target_id = cursor.fetchone()
                        if target_id and u_id == target_id[0]:
                            return rank, total
                
                return None, None

        def get_user_pr_rank(user_id):
            """计算用户的 PR 排名"""
            query = '''
                WITH user_stats AS (
                    SELECT 
                        total,
                        (SELECT COUNT(*) FROM users WHERE total > u.total) * 100.0 / 
                        (SELECT COUNT(*) FROM users) AS pr_percentage
                    FROM users u
                    WHERE user_id = ?
                )
                SELECT pr_percentage 
                FROM user_stats
            '''
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                cursor.execute(query, (user_id,))
                result = cursor.fetchone()
                if result:
                    return round(result[0], 3)
                return None

        def classify_by_percentage(percentage):
            """根据百分比分类段位"""
            if percentage <= 1:
                return '大師冠貓'
            elif percentage <= 10:
                return '鑽石冠貓'
            elif percentage <= 20:
                return '白金冠貓'
            elif percentage <= 30:
                return '黃金冠貓'
            elif percentage <= 40:
                return '白銀冠貓'
            elif percentage <= 50:
                return '青銅冠貓'
            else:
                return '簡單貓'

        # 如果提供了 user_name，则查询该用户的信息
        if user_name:
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT user_id FROM users WHERE user_name = ?', (user_name,))
                user_id = cursor.fetchone()
                if user_id:
                    user_id = user_id[0]
                else:
                    await ctx.reply(f"@{ctx.author.name} 找不到用戶 {user_name}")
                    return
        else:
            # 否则查询当前用户的信息
            user_id = ctx.author.id

        score, count, total = get_user_data(user_id=user_id)
        rank, total = get_user_rank(user_id=user_id)
        pr = get_user_pr_rank(user_id=user_id)

        if score is not None and count is not None:
            if user_name:  # 查询其他用户时
                if rank <= 20:
                    await ctx.reply(f"@{ctx.author.name} {user_name} 的數據: 總積分--{total} 階級--菁英冠貓 #{rank} ({pr}%). 聊天數:{count} | 共觀看:{score * 0.25} hr")
                else:
                    await ctx.reply(f"@{ctx.author.name} {user_name} 的數據: 總積分--{total} 階級--{classify_by_percentage(pr)} #{rank} ({pr}%). 聊天數:{count} | 共觀看:{score * 0.25} hr")
            else:  # 查询自己时
                if rank <= 20:
                    await ctx.reply(f"@{ctx.author.name} guanwe1Gan 總積分--{total} 階級--菁英冠貓 #{rank} ({pr}%). 聊天數:{count} | 共觀看:{score * 0.25} hr")
                else:
                    await ctx.reply(f"@{ctx.author.name} guanwe1Gan 總積分--{total} 階級--{classify_by_percentage(pr)} #{rank} ({pr}%). 聊天數:{count} | 共觀看:{score * 0.25} hr")



    @commands.command(name='top10')
    async def top10(self, ctx: commands.Context):
        cooldown = 25  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('top10', cooldown)

        if remaining_time:
            return
        
        rank_labels = ["1st", "2nd", "3rd"] + [f"{i}th" for i in range(4, 11)]  # 定義排名格式
        formatted_top_users = []
        skip_users = {"Nightbot"}
        
        try:
            # 連接資料庫
            conn = sqlite3.connect("D:/userslevel.db")
            cursor = conn.cursor()
            
            # 查詢前十名用戶（根據你的需求排序，這裡假設以 total 降序排序）
            query = "SELECT user_name FROM users ORDER BY total DESC LIMIT 12"
            cursor.execute(query)
            results = cursor.fetchall()
            
            # 遍歷結果，跳過 "Nightbot"，只記錄前十名
            count = 0
            for user_name, in results:
                if user_name in skip_users:
                    continue  
                
                formatted_top_users.append(f"{rank_labels[count]}: {user_name}")
                count += 1
                
                if count == 10:  # 只記錄前十名
                    break
            
            conn.close()
        except Exception as e:
            print(f"資料庫操作失敗: {e}")
    
        await ctx.reply(f'@{ctx.author.name} 魯蛇排行---{" ".join(formatted_top_users)}')

    @commands.command(name='history')
    async def history(self, ctx: commands.Context):

        cooldown = 10  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('history', cooldown)

        if remaining_time:
            return

        import sqlite3

        # 連接 3月資料庫
        def march(user_id):
            conn_march = sqlite3.connect("D:/march.db")
            cursor_march = conn_march.cursor()

            cursor_march.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_march.fetchone()
            conn_march.close()
            if result:
                return result
            else:
                return ("N", "無資料")

        # 連接 4月資料庫
        def april(user_id):
            conn_april = sqlite3.connect("D:/april.db")
            cursor_april = conn_april.cursor()

            cursor_april.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_april.fetchone()
            conn_april.close()
            if result:
                return result
            else:
                return ("N", "無資料")
        
        # 連接 5月資料庫
        def may(user_id):
            conn_may = sqlite3.connect("D:/may.db")
            cursor_may = conn_may.cursor()

            cursor_may.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_may.fetchone()
            conn_may.close()
            if result:
                return result
            else:
                return ("N", "無資料")

        # 連接 6月資料庫
        def june(user_id):
            conn_june = sqlite3.connect("D:/june.db")
            cursor_june = conn_june.cursor()

            cursor_june.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_june.fetchone()
            conn_june.close()
            if result:
                return result
            else:
                return ("N", "無資料")
        
        # 連接 7月資料庫
        def july(user_id):
            conn_july = sqlite3.connect("D:/july.db")
            cursor_july = conn_july.cursor()

            cursor_july.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_july.fetchone()
            conn_july.close()
            if result:
                return result
            else:
                return ("N", "無資料")

        user_id = ctx.author.id

        march_result = march(user_id)
        april_result = april(user_id)
        may_result = may(user_id)
        june_result = june(user_id)
        july_result = july(user_id)  

        if user_id == '152701250': #minglee
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #1 [發言王] | 4月:菁英冠貓 #1 [發言王] | 5月:菁英冠貓 #1 [發言王] | 6月:菁英冠貓 #2 | 7月:菁英冠貓 #1 [發言王]")
        elif user_id == '147080444': #斑斑
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #4 [掛台王] | 4月:菁英冠貓 #4 [掛台王] | 5月:宗師冠貓 #21 | 6月:宗師冠貓 #21 | 7月:大師冠貓 #23")
        elif user_id == '109499201': #冠緯一貓六
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #2 | 4月:菁英冠貓 #2 [守靈幫主] | 5月:菁英冠貓 #2 [守靈幫主] | 6月:菁英冠貓 #3 [守靈幫主] | 7月:菁英冠貓 #2")
        elif user_id == '93228342': #XDD
            await ctx.reply(f"歷史冠貓榜排行 - 3月:大師冠貓 #205 | 4月:鑽石冠貓 #2492 | 5月:鑽石冠貓 #926 [標記幫主] | 6月:鑽石冠貓 #1135 | 7月:白金冠貓 #3164")
        elif user_id == '28212434': #班長
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #5 | 4月:菁英冠貓 #7 | 5月:菁英冠貓 #8 [掛台王] | 6月:菁英冠貓 #12 | 7月:菁英冠貓 #7 [掛台王]")
        elif user_id == '643304176': #yukaikyu
            await ctx.reply(f"歷史冠貓榜排行 - 3月:鑽石冠貓 #624 | 4月:大師冠貓 #144 | 5月:大師冠貓 #52 | 6月:菁英冠貓 #1 [發言王] | 7月:大師冠貓 #193")
        elif user_id == '695807373': #熊貓狗_叉滴
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #11 | 4月:菁英冠貓 #6 | 5月:菁英冠貓 #6 | 6月:菁英冠貓 #8 [掛台王] | 7月:菁英冠貓 #8")
        else:
            print("DEBUG:", march_result, april_result, may_result, june_result, july_result)
            await ctx.reply(f"歷史冠貓榜排行 - 3月:{march_result[1]} #{march_result[0]} | 4月:{april_result[1]} #{april_result[0]} | 5月:{may_result[1]} #{may_result[0]} | 6月:{june_result[1]} #{june_result[0]} | 7月:{july_result[1]} #{july_result[0]}")


    @commands.command(name='底分')
    async def cutoff(self, ctx: commands.Context):
        cooldown = 10  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('cutoff', cooldown)

        if remaining_time:
            return
        
        # 初始化瀏覽器（無頭模式）
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')  # 不開啟實體瀏覽器
        options.add_argument('--disable-gpu')

        # 設定 ChromeDriver 路徑
        service = Service("C:/chromedriver.exe")  # 替換為你的 chromedriver 路徑

        # 啟動 WebDriver
        driver = webdriver.Chrome(service=service, options=options)

        # 開啟網頁
        url = "https://www.deeplol.gg/ranking/kr/all"
        driver.get(url)

        # 等待資料載入（可以視情況調整時間或加上等待條件）
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "sc-fpGCtG.iNYNXx"))
        )

        # 抓取 class="sc-fpGCtG iNYNXx" 的所有元素
        elements = driver.find_elements(By.CLASS_NAME, "sc-fpGCtG.iNYNXx")

        results = []

        for i, elem in enumerate(elements, start=1):
            results.append(elem.text)

        await ctx.reply(f"@{ctx.author.name} 菁英:{results[0]} | 宗師:{results[1]}")

        # 關閉瀏覽器
        driver.quit()

        
    @commands.command(name='test')
    async def streamodds(self, ctx: commands.Context):
        def estimate_stream_prob_v3(day3, day2, day1, has_sponsor, now=None):
            if has_sponsor == 1:
                return 100.0

            if now is None:
                now = datetime.now()

            base_score = 50
            penalty = day3 * 10 + day2 * 15 + day1 * 25
            bonus_rest = 20 if day3 + day2 + day1 == 0 else 0
            total_minutes = now.hour * 60 + now.minute
            time_bonus = ((1440 - total_minutes) / 1440) * 20
            is_weekend = now.weekday() in [5, 6]
            weekend_bonus = 10 if is_weekend else 0
            random_offset = random.uniform(-2.5, 2.5)

            final_score = base_score - penalty + bonus_rest + time_bonus + weekend_bonus + random_offset
            return round(max(min(final_score, 100), 1), 1)

        # === 掛載 Google Sheets ===
        gc = pygsheets.authorize(service_account_file='alien-emblem-428413-f3-bc4414585a15.json')        
        url = 'https://docs.google.com/spreadsheets/d/11aNVYLlKuOBEfz0EUFdTFrLfMoubJCyJpQedbysQ6JI/edit?gid=0#gid=0'
        sh = gc.open_by_url(url)
        ws = sh.worksheet_by_title('工作表1')

        # === 讀取資料（跳過標題列）===

        day3 = int(ws.get_value('A2'))
        day2 = int(ws.get_value('B2'))
        day1 = int(ws.get_value('C2'))
        has_sponsor = int(ws.get_value('D2'))

        score = estimate_stream_prob_v3(day3, day2, day1, has_sponsor)
        print(day3)
        print(day2)
        print(score)
        #await ctx.reply(f'今天的開台機率為：{str(score)}%!')

bot = Bot()
bot.run()