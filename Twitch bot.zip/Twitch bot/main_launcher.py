# launcher.py — 第1個 panel 含自動重啟與進度條，第2/3 無進度條且不自動重啟
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
from tkinter import ttk
import subprocess
import threading
import time
import os
import signal
import sys

# === CONFIG ===
WORKER_SCRIPTS = [
    os.path.join(os.path.dirname(__file__), "guanweibot.py"),
    os.path.join(os.path.dirname(__file__), "chatcount.py"),
    os.path.join(os.path.dirname(__file__), "viewtime.py"),
]
RESTART_INTERVAL = 3 * 60
PYTHON_EXE = sys.executable
COUNTDOWN_TICK_MS = 1000

# === STYLE ===
def make_style(root):
    style = ttk.Style(root)
    try:
        style.theme_use('clam')
    except Exception:
        pass
    style.configure('.', font=("Segoe UI", 10))
    style.configure('Accent.TButton', foreground='white', padding=(6,4))
    style.map('Accent.TButton', background=[('active', '#2278f3'), ('!disabled', '#2a8bf2')])
    try:
        style.configure("big.Horizontal.TProgressbar", thickness=12)
    except Exception:
        pass
    return style

class StatusDot(tk.Canvas):
    def __init__(self, master, size=12, **kwargs):
        super().__init__(master, width=size, height=size, highlightthickness=0, bd=0, **kwargs)
        self.size = size
        self.dot = self.create_oval(2, 2, size-2, size-2, fill="#999999", outline="")
    def set_color(self, color):
        self.itemconfig(self.dot, fill=color)

# === PANEL ===
class WorkerPanel(ttk.Frame):
    def __init__(self, parent, script_path, restart_interval=RESTART_INTERVAL, auto_restart=True, show_progress=True, *args, **kwargs):
        super().__init__(parent, padding=8, *args, **kwargs)
        self.script_path = script_path
        self.restart_interval = restart_interval
        self.auto_restart = auto_restart
        self.show_progress = show_progress

        self.proc = None
        self.monitor_thread = None
        self.restarting = False
        self.lock = threading.Lock()
        self.next_restart_time = None
        self._countdown_after_id = None

        # --- UI ---
        top = ttk.Frame(self)
        top.pack(fill="x", pady=(0,6))

        ttk.Label(top, text=os.path.basename(script_path), font=("Segoe UI Semibold", 11)).pack(side="left", padx=(0,8))

        btnf = ttk.Frame(top)
        btnf.pack(side="left")
        self.start_btn = ttk.Button(btnf, text="Start", command=self.start_worker, style='Accent.TButton')
        self.start_btn.grid(row=0, column=0, padx=(0,4))
        self.stop_btn = ttk.Button(btnf, text="Stop", command=lambda: self.stop_worker(wait=False), state="disabled")
        self.stop_btn.grid(row=0, column=1, padx=(0,4))
        if auto_restart:
            self.restart_btn = ttk.Button(btnf, text="Restart", command=self.restart_worker, state="disabled")
            self.restart_btn.grid(row=0, column=2, padx=(0,4))
        else:
            self.restart_btn = None

        statf = ttk.Frame(top)
        statf.pack(side="left", padx=(12,8))
        ttk.Label(statf, text="Status:").pack(side="left")
        self.status_dot = StatusDot(statf, size=12)
        self.status_dot.pack(side="left", padx=(4,6))
        self.status_label = ttk.Label(statf, text="stopped")
        self.status_label.pack(side="left")

        # 倒數與進度條
        self.cdf = ttk.Frame(top)
        self.cdf.pack(side="right", fill="x", expand=True)
        ttk.Label(self.cdf, text="Next restart").pack(anchor="e")
        self.countdown_label = ttk.Label(self.cdf, text="N/A")
        self.countdown_label.pack(anchor="e")
        if self.show_progress:
            self.progress = ttk.Progressbar(self.cdf, orient="horizontal", mode="determinate", style="big.Horizontal.TProgressbar")
            self.progress.pack(fill="x", expand=True, pady=(4,0))
        else:
            self.progress = None

        # Log 區
        self.log = ScrolledText(self, height=8, state="disabled", wrap="none", font=("Consolas", 10))
        self.log.pack(fill="both", expand=True)

        self._set_status("stopped", "#b0b0b0")
        self._countdown_tick()

    # --- UI helpers ---
    def write_log(self, text):
        def _w():
            self.log['state'] = 'normal'
            self.log.insert('end', text)
            self.log.see('end')
            self.log['state'] = 'disabled'
        self.after(0, _w)
    def _set_status(self, text, color):
        self.status_label.config(text=text)
        self.status_dot.set_color(color)

    # --- Process control ---
    def start_worker(self):
        with self.lock:
            if self.proc and self.proc.poll() is None:
                self.write_log("Already running.\n")
                return

            self.write_log(f"Starting: {self.script_path}\n")
            if os.name == 'nt':
                popen_args = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP, "bufsize": 1, "text": True, "encoding": "utf-8", "errors": "replace"}
            else:
                popen_args = {"preexec_fn": os.setsid, "bufsize": 1, "text": True, "encoding": "utf-8", "errors": "replace"}

            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"

            try:
                self.proc = subprocess.Popen([PYTHON_EXE, self.script_path],
                                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, **popen_args)
            except Exception as e:
                self.write_log(f"Failed to start: {e}\n")
                self.proc = None
                return

            self.start_btn.config(state='disabled')
            self.stop_btn.config(state='normal')
            if self.restart_btn:
                self.restart_btn.config(state='normal')
            self._set_status("running", "#2bbf6b")

            self.monitor_thread = threading.Thread(target=self._monitor_proc, daemon=True)
            self.monitor_thread.start()

            if self.auto_restart:
                self.next_restart_time = time.time() + self.restart_interval
                self._update_progress_ui(0)
            else:
                self.next_restart_time = None
                self._update_progress_ui(0)

    def stop_worker(self, wait=False):
        with self.lock:
            if not self.proc or self.proc.poll() is not None:
                self.write_log("Not running.\n")
                return
            self.write_log("Stopping...\n")
            try:
                if os.name == 'nt':
                    self.proc.send_signal(signal.CTRL_BREAK_EVENT)
                    self.proc.wait(timeout=3)
                else:
                    os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
                    self.proc.wait(timeout=3)
            except Exception:
                try:
                    self.proc.terminate()
                except Exception:
                    pass
            if wait:
                try:
                    self.proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
            else:
                threading.Thread(target=self._wait_and_update_ui, daemon=True).start()
            self._cancel_countdown_schedule()

    def restart_worker(self):
        self.write_log("Manual restart requested.\n")
        threading.Thread(target=self._do_restart_in_bg, daemon=True).start()
    def _do_restart_in_bg(self):
        self.restarting = True
        self.stop_worker(wait=True)
        time.sleep(0.5)
        self.start_worker()
        self.restarting = False

    def _monitor_proc(self):
        def _reader(pipe, prefix=""):
            for line in iter(pipe.readline, ''):
                if not line:
                    break
                self.write_log(f"{prefix}{line}")
        threading.Thread(target=_reader, args=(self.proc.stdout, "OUT: "), daemon=True).start()
        threading.Thread(target=_reader, args=(self.proc.stderr, "ERR: "), daemon=True).start()
        self.proc.wait()
        self.write_log(f"Exited with code {self.proc.returncode}\n")
        self.start_btn.config(state='normal')
        self.stop_btn.config(state='disabled')
        if self.restart_btn:
            self.restart_btn.config(state='disabled')
        self._set_status("stopped", "#b0b0b0")

    def _wait_and_update_ui(self):
        self.proc.wait(timeout=5)
        self.start_btn.config(state='normal')
        self.stop_btn.config(state='disabled')
        if self.restart_btn:
            self.restart_btn.config(state='disabled')
        self._set_status("stopped", "#b0b0b0")

    # --- Countdown ---
    def _countdown_tick(self):
        if not self.auto_restart:
            self.countdown_label.config(text="N/A")
            self._update_progress_ui(0)
        else:
            now = time.time()
            nxt = self.next_restart_time
            interval = self.restart_interval
            if nxt is None or not self.proc or self.proc.poll() is not None:
                self.countdown_label.config(text="N/A")
                self._update_progress_ui(0)
            else:
                remaining = max(0, int(nxt - now))
                self.countdown_label.config(text=f"{remaining//60:02d}:{remaining%60:02d}")
                self._update_progress_ui(interval - remaining)
                if remaining <= 0:
                    self.write_log("Auto-restart fired.\n")
                    self.next_restart_time = None
                    threading.Thread(target=self._do_restart_in_bg, daemon=True).start()
        self._countdown_after_id = self.after(COUNTDOWN_TICK_MS, self._countdown_tick)

    def _update_progress_ui(self, elapsed_seconds):
        if self.progress:
            self.progress['maximum'] = self.restart_interval
            self.progress['value'] = elapsed_seconds

    def _cancel_countdown_schedule(self):
        if self._countdown_after_id:
            self.after_cancel(self._countdown_after_id)
            self._countdown_after_id = None
        self.next_restart_time = None
        self.countdown_label.config(text="N/A")
        self._update_progress_ui(0)
        self._countdown_after_id = self.after(COUNTDOWN_TICK_MS, self._countdown_tick)

    def on_closing(self):
        if self._countdown_after_id:
            self.after_cancel(self._countdown_after_id)
            self._countdown_after_id = None
        if self.proc and self.proc.poll() is None:
            self.stop_worker(wait=True)

# === 主介面 ===
class LauncherApp(tk.Tk):
    def __init__(self, scripts):
        super().__init__()
        self.title("Twitch Bot Launcher")
        self.geometry("1000x820")
        make_style(self)

        container = ttk.Frame(self, padding=10)
        container.pack(fill="both", expand=True)

        header = ttk.Frame(container)
        header.pack(fill="x", pady=(0,8))
        ttk.Label(header, text="Twitch Bot Launcher", font=("Segoe UI Semibold", 14)).pack(side="left")

        panels_frame = ttk.Frame(container)
        panels_frame.pack(fill="both", expand=True)

        self.panels = []
        for idx, s in enumerate(scripts):
            # 只有第一個 panel 顯示進度條與自動重啟
            auto_restart = (idx == 0)
            show_progress = (idx == 0)
            p = WorkerPanel(panels_frame, s, auto_restart=auto_restart, show_progress=show_progress)
            p.pack(fill="both", expand=True, pady=(0,10))
            if idx < len(scripts) - 1:
                ttk.Separator(panels_frame, orient="horizontal").pack(fill="x", pady=(0,8))
            self.panels.append(p)

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _on_close(self):
        for p in self.panels:
            p.on_closing()
        self.destroy()

if __name__ == "__main__":
    app = LauncherApp(WORKER_SCRIPTS)
    app.mainloop()
