# launcher.py — 多面板版（第1個 panel 啟用自動重啟，第2/3個關閉自動重啟）
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
from tkinter import ttk
import subprocess
import threading
import time
import os
import signal
import sys

# ---- CONFIG ----
# 把這裡改成你要同時顯示／控制的三個 script（絕對或相對路徑皆可）
WORKER_SCRIPTS = [
    os.path.join(os.path.dirname(__file__), "guanweibot.py"),
    os.path.join(os.path.dirname(__file__), "chatcount.py"),
    os.path.join(os.path.dirname(__file__), "viewtime.py"),
]

RESTART_INTERVAL = 15 * 60  # 每個 panel 的自動重啟預設秒數
PYTHON_EXE = sys.executable
COUNTDOWN_TICK_MS = 1000

# ---- Styling helper (簡單) ----
def make_style(root):
    style = ttk.Style(root)
    try:
        style.theme_use('clam')
    except Exception:
        pass
    style.configure('.', font=("Segoe UI", 10))
    style.configure('Accent.TButton', foreground='white', padding=(6,4))
    style.map('Accent.TButton', background=[('active', '#2278f3'), ('!disabled', '#2a8bf2')])
    # 大進度條樣式（部分平台可能不完全支援 thickness）
    try:
        style.configure("big.Horizontal.TProgressbar", thickness=12)
    except Exception:
        pass
    return style

# 小狀態圓點（直接使用 tk.Canvas 以避免 ttk/bg 問題）
class StatusDot(tk.Canvas):
    def __init__(self, master, size=12, bg=None, **kwargs):
        # 若有給 bg，用它；否則不指定，讓系統處理
        opts = {}
        if bg:
            opts['bg'] = bg
        super().__init__(master, width=size, height=size, highlightthickness=0, bd=0, **opts)
        self.size = size
        self.dot = self.create_oval(2, 2, size-2, size-2, fill="#999999", outline="")

    def set_color(self, color):
        try:
            self.itemconfig(self.dot, fill=color)
        except Exception:
            pass

# ---- 每個 script 的控制面板 ----
class WorkerPanel(ttk.Frame):
    def __init__(self, parent, script_path, restart_interval=RESTART_INTERVAL, auto_restart=True, *args, **kwargs):
        super().__init__(parent, padding=8, *args, **kwargs)
        self.script_path = script_path
        self.restart_interval = restart_interval
        self.auto_restart = auto_restart

        # internal state
        self.proc = None
        self.monitor_thread = None
        self.restarting = False
        self.lock = threading.Lock()
        self.next_restart_time = None
        self._countdown_after_id = None

        # UI layout
        top = ttk.Frame(self)
        top.pack(fill="x", pady=(0,6))

        name = os.path.basename(script_path)
        ttk.Label(top, text=name, font=("Segoe UI Semibold", 11)).pack(side="left", padx=(0,8))

        # buttons
        btn_frame = ttk.Frame(top)
        btn_frame.pack(side="left")
        self.start_btn = ttk.Button(btn_frame, text="Start", command=self.start_worker, style='Accent.TButton')
        self.start_btn.grid(row=0, column=0, padx=(0,4))
        self.stop_btn = ttk.Button(btn_frame, text="Stop", command=lambda: self.stop_worker(wait=False), state="disabled")
        self.stop_btn.grid(row=0, column=1, padx=(0,4))

        if self.auto_restart:
            self.restart_btn = ttk.Button(btn_frame, text="Restart", command=self.restart_worker, state="disabled")
            self.restart_btn.grid(row=0, column=2, padx=(0,4))
        else:
            self.restart_btn = None  # 保持向後相容

        # status
        status_frame = ttk.Frame(top)
        status_frame.pack(side="left", padx=(12,8))
        ttk.Label(status_frame, text="Status:").pack(side="left")
        # 若想指定背景色，可傳 bg=self.winfo_toplevel().cget('bg')
        try:
            bg = self.winfo_toplevel().cget('bg')
        except Exception:
            bg = None
        self.status_dot = StatusDot(status_frame, size=12, bg=bg)
        self.status_dot.pack(side="left", padx=(4,6))
        self.status_label = ttk.Label(status_frame, text="stopped")
        self.status_label.pack(side="left")

        # countdown & progress
        cd_frame = ttk.Frame(top)
        cd_frame.pack(side="right", fill="x", expand=True)
        ttk.Label(cd_frame, text="Next restart").pack(anchor="e")
        self.countdown_label = ttk.Label(cd_frame, text="N/A")
        self.countdown_label.pack(anchor="e")
        # 使用可擴展寬度的 progressbar 並套用較粗的 style
        self.progress = ttk.Progressbar(cd_frame, orient="horizontal", mode="determinate", style="big.Horizontal.TProgressbar")
        self.progress.pack(fill="x", expand=True, pady=(4,0))

        # log area (per-panel)
        self.log = ScrolledText(self, height=8, state="disabled", wrap="none", font=("Consolas", 10))
        self.log.pack(fill="both", expand=True)

        # initial UI state
        self._set_status("stopped", "#b0b0b0")
        # 啟動倒數 after loop
        self._countdown_tick()

    # ---------- UI helpers ----------
    def write_log(self, text):
        def _w():
            self.log['state'] = 'normal'
            self.log.insert('end', text)
            self.log.see('end')
            self.log['state'] = 'disabled'
        try:
            self.after(0, _w)
        except Exception:
            _w()

    def _set_status(self, text, color):
        try:
            self.status_label.config(text=text)
            self.status_dot.set_color(color)
        except Exception:
            pass

    # ---------- process control ----------
    def start_worker(self):
        with self.lock:
            if self.proc and self.proc.poll() is None:
                self.write_log("Already running.\n")
                return

            self.write_log(f"Starting: {self.script_path}\n")
            popen_args = {}
            if os.name == 'nt':
                popen_args = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP, "bufsize": 1, "text": True, "encoding": "utf-8", "errors": "replace"}
            else:
                popen_args = {"preexec_fn": os.setsid, "bufsize": 1, "text": True, "encoding": "utf-8", "errors": "replace"}

            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"

            cmd = [PYTHON_EXE, self.script_path]
            try:
                self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, **popen_args)
            except Exception as e:
                self.write_log(f"Failed to start: {e}\n")
                self.proc = None
                return

            # UI
            try:
                self.start_btn.state(['disabled'])
                self.stop_btn.state(['!disabled'])
                if self.restart_btn is not None:
                    self.restart_btn.state(['!disabled'])
            except Exception:
                self.start_btn.config(state='disabled')
                self.stop_btn.config(state='normal')
                if self.restart_btn is not None:
                    self.restart_btn.config(state='normal')

            self._set_status("running", "#2bbf6b")

            # start monitor thread
            self.monitor_thread = threading.Thread(target=self._monitor_proc, daemon=True)
            self.monitor_thread.start()

            # schedule next restart (only if auto_restart enabled)
            if self.auto_restart:
                self.next_restart_time = time.time() + self.restart_interval
                self._update_progress_ui(0)
                self.write_log(f"Scheduled next auto-restart in {self.restart_interval} seconds.\n")
            else:
                self.next_restart_time = None
                self._update_progress_ui(0)
                self.write_log("Auto-restart disabled for this panel.\n")

    def stop_worker(self, wait=False):
        with self.lock:
            if not self.proc or self.proc.poll() is not None:
                self.write_log("Not running.\n")
                self._cancel_countdown_schedule()
                return

            self.write_log("Stopping...\n")
            try:
                if os.name == 'nt':
                    try:
                        self.proc.send_signal(signal.CTRL_BREAK_EVENT)
                    except Exception:
                        pass
                    try:
                        self.proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        try:
                            self.proc.terminate()
                        except Exception:
                            pass
                else:
                    try:
                        os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
                    except Exception:
                        try:
                            self.proc.terminate()
                        except Exception:
                            pass

                if wait:
                    try:
                        self.proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        try:
                            self.proc.kill()
                        except Exception:
                            pass
                else:
                    threading.Thread(target=self._wait_and_update_ui, daemon=True).start()
            except Exception as e:
                self.write_log(f"Error stopping: {e}\n")

            self._cancel_countdown_schedule()

    def restart_worker(self):
        # manual restart (if restart_btn exists)
        if not self.auto_restart and self.restart_btn is None:
            # 如果沒有 restart 按鈕，仍允許手動呼叫 restart via code? 這裡直接 ignore
            self.write_log("Manual restart is disabled for this panel.\n")
            return
        self.write_log("Manual restart requested.\n")
        threading.Thread(target=self._do_restart_in_bg, daemon=True).start()

    def _do_restart_in_bg(self):
        self.restarting = True
        self.stop_worker(wait=True)
        time.sleep(0.5)
        self.start_worker()
        self.restarting = False

    def _monitor_proc(self):
        def _reader(pipe, prefix=""):
            try:
                for line in iter(pipe.readline, ''):
                    if not line:
                        break
                    self.write_log(f"{prefix}{line}")
            except Exception as e:
                self.write_log(f"[reader error] {e}\n")
            finally:
                try:
                    pipe.close()
                except Exception:
                    pass

        threads = []
        if self.proc and self.proc.stdout:
            t = threading.Thread(target=_reader, args=(self.proc.stdout, "OUT: "), daemon=True)
            t.start(); threads.append(t)
        if self.proc and self.proc.stderr:
            t2 = threading.Thread(target=_reader, args=(self.proc.stderr, "ERR: "), daemon=True)
            t2.start(); threads.append(t2)

        if self.proc:
            ret = None
            try:
                ret = self.proc.wait()
            except Exception as e:
                self.write_log(f"Wait error: {e}\n")
            self.write_log(f"Exited with code {ret}\n")

        with self.lock:
            if not self.restarting:
                def _upd():
                    try:
                        self.start_btn.state(['!disabled'])
                        self.stop_btn.state(['disabled'])
                        if self.restart_btn is not None:
                            self.restart_btn.state(['disabled'])
                    except Exception:
                        self.start_btn.config(state='normal')
                        self.stop_btn.config(state='disabled')
                        if self.restart_btn is not None:
                            self.restart_btn.config(state='disabled')
                    self._set_status("stopped", "#b0b0b0")
                try:
                    self.after(0, _upd)
                except Exception:
                    _upd()
                self._cancel_countdown_schedule()

    def _wait_and_update_ui(self):
        if self.proc:
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    self.proc.kill()
                except Exception:
                    pass
        def _upd():
            try:
                self.start_btn.state(['!disabled'])
                self.stop_btn.state(['disabled'])
                if self.restart_btn is not None:
                    self.restart_btn.state(['disabled'])
            except Exception:
                self.start_btn.config(state='normal')
                self.stop_btn.config(state='disabled')
                if self.restart_btn is not None:
                    self.restart_btn.config(state='disabled')
            self._set_status("stopped", "#b0b0b0")
        try:
            self.after(0, _upd)
        except Exception:
            _upd()

    # ---------- countdown using after ----------
    def _countdown_tick(self):
        now = time.time()
        nxt = self.next_restart_time
        interval = self.restart_interval

        if nxt is None or not self.proc or (self.proc and self.proc.poll() is not None):
            self.countdown_label.config(text="N/A")
            self._update_progress_ui(0)
        else:
            remaining = max(0, int(nxt - now))
            mins = remaining // 60
            secs = remaining % 60
            self.countdown_label.config(text=f"{mins:02d}:{secs:02d}")
            elapsed = max(0, interval - remaining)
            self._update_progress_ui(elapsed)
            if remaining <= 0:
                if self.auto_restart:
                    self.write_log("Auto-restart fired.\n")
                    self.next_restart_time = None
                    threading.Thread(target=self._do_restart_in_bg, daemon=True).start()
                else:
                    # auto restart disabled -> stop countdown display
                    self.next_restart_time = None
                    self.countdown_label.config(text="N/A")
                    self._update_progress_ui(0)

        self._countdown_after_id = self.after(COUNTDOWN_TICK_MS, self._countdown_tick)

    def _update_progress_ui(self, elapsed_seconds):
        try:
            self.progress['maximum'] = self.restart_interval
            self.progress['value'] = elapsed_seconds
        except Exception:
            pass

    def _cancel_countdown_schedule(self):
        if self._countdown_after_id:
            try:
                self.after_cancel(self._countdown_after_id)
            except Exception:
                pass
            self._countdown_after_id = None
        self.next_restart_time = None
        self.countdown_label.config(text="N/A")
        self._update_progress_ui(0)
        # keep the after loop alive
        self._countdown_after_id = self.after(COUNTDOWN_TICK_MS, self._countdown_tick)

    def on_closing(self):
        if self._countdown_after_id:
            try:
                self.after_cancel(self._countdown_after_id)
            except Exception:
                pass
            self._countdown_after_id = None
        if self.proc and self.proc.poll() is None:
            self.stop_worker(wait=True)

# ---- 主視窗: 建三個 WorkerPanel 並排或直列 ----
class LauncherApp(tk.Tk):
    def __init__(self, scripts):
        super().__init__()
        self.title("Multi-Worker Launcher")
        self.geometry("1000x820")
        make_style(self)

        container = ttk.Frame(self, padding=10)
        container.pack(fill="both", expand=True)

        # header
        header = ttk.Frame(container)
        header.pack(fill="x", pady=(0,8))
        ttk.Label(header, text="Multi Worker Launcher", font=("Segoe UI Semibold", 14)).pack(side="left")
        ttk.Label(header, text="（每組為獨立控制）").pack(side="left", padx=(6,0))

        # Create a vertical stack of panels — each panel controls one script
        panels_frame = ttk.Frame(container)
        panels_frame.pack(fill="both", expand=True)

        self.panels = []
        for idx, s in enumerate(scripts):
            # 只有第一個 panel 開啟 auto_restart，第二與第三關閉
            auto_restart_flag = True if idx == 0 else False
            p = WorkerPanel(panels_frame, s, auto_restart=auto_restart_flag)
            p.pack(fill="both", expand=True, pady=(0,10))
            if idx < len(scripts) - 1:
                ttk.Separator(panels_frame, orient="horizontal").pack(fill="x", pady=(0,8))
            self.panels.append(p)

        # Close handling: ensure all panels stop their procs before exit
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _on_close(self):
        for p in self.panels:
            try:
                p.on_closing()
            except Exception:
                pass
        self.destroy()


if __name__ == "__main__":
    # ensure scripts exist (warning if not)
    missing = [p for p in WORKER_SCRIPTS if not os.path.isfile(p)]
    if missing:
        print("Warning: some worker scripts not found:", missing)
    app = LauncherApp(WORKER_SCRIPTS)
    app.mainloop()
