import sqlite3
import math
import time
import json

def average_top_1_percent_count(db_path):
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM users')
        total_users = cursor.fetchone()[0]

        if total_users == 0:
            return None

        top_n = max(1, math.ceil(total_users * 0.03))
        cursor.execute('SELECT count FROM users ORDER BY count DESC LIMIT ?', (top_n,))
        counts = [row[0] for row in cursor.fetchall()]
        return sum(counts) / len(counts)

def write_to_json(avg_value, output_path='avg_result.json'):
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump({"avg_top_3_percent": avg_value}, f)

db_path = 'userslevel.db'

while True:
    avg = average_top_1_percent_count(db_path)
    print(f"前 3% 使用者的平均 count 為：{avg}")
    write_to_json(avg)
    time.sleep(300)  # 300秒 
