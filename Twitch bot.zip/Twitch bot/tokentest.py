# app.py
from flask import Flask, request
import requests

app = Flask(__name__)
CLIENT_ID = '<YOUR_CLIENT_ID>'
CLIENT_SECRET = '<YOUR_CLIENT_SECRET>'
REDIRECT_URI = 'http://localhost:3000/callback'

@app.route('/callback')
def callback():
    code = request.args.get('code')
    if not code:
        return 'no code', 400
    token_resp = requests.post('https://id.twitch.tv/oauth2/token', data={
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'code': code,
        'grant_type': 'authorization_code',
        'redirect_uri': REDIRECT_URI
    })
    return token_resp.json()

if __name__ == '__main__':
    app.run(port=3000)
