from twitchio.ext import commands
from dataclasses import dataclass
import json
import requests
import random
import time
import sqlite3
from datetime import datetime, timedelta
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import pygsheets


def make_request(url):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Check if the request was successful
        return response.json()  # Return the JSON response
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")  # Print HTTP error
    except Exception as err:
        print(f"Other error occurred: {err}")  # Print any other error

def rank():
    apikey = 'RGAPI-66e6defb-ed79-4420-999b-8c195f81f0d4'
    url = f"https://kr.api.riotgames.com/lol/league/v4/entries/by-puuid/sbqISc8a1sTBLZT_UmNbieKzv3oCTPFHmC2hGTZBGyhS57wTzSoWt3iw8oI1xrNX4EjJVk9-oUvTpQ?api_key={apikey}"  # Replace with your request URL
    result = make_request(url)

    if result:
        print("Request was successful.")
        print("Response:")
        #print(result)
        return(result[0]['tier'],result[0]['rank'],result[0]['leaguePoints'],result[0]['wins'],result[0]['losses'])
    else:
        print("Failed to retrieve data.")

def challenger():
    import requests

    apikey = 'RGAPI-fa134c9f-770a-464c-94a7-b61e47b84d3e'
    url = f"https://kr.api.riotgames.com/lol/league/v4/challengerleagues/by-queue/RANKED_SOLO_5x5?api_key={apikey}"

    response = requests.get(url)

    if response.status_code == 200:
        result = response.json()
        entries = result.get('entries', [])

        # 確保資料數量夠
        if len(entries) >= 300:
            player = entries[299]  # 第 300 名（索引從 0 開始）
            return player['leaguePoints']
        else:
            print(f"Only found {len(entries)} players in the response.")
            return None
    else:
        print("Failed to retrieve data.")
        print("Status Code:", response.status_code)
        return None

def grand():
    import requests

    apikey = 'RGAPI-fa134c9f-770a-464c-94a7-b61e47b84d3e'
    url = f"https://kr.api.riotgames.com/lol/league/v4/grandmasterleagues/by-queue/RANKED_SOLO_5x5?api_key={apikey}"

    response = requests.get(url)

    if response.status_code == 200:
        result = response.json()
        entries = result.get('entries', [])

        # 確保資料數量夠
        if len(entries) >= 699:
            player = entries[699]  # 第 300 名（索引從 0 開始）
            return player['leaguePoints']
        else:
            print(f"Only found {len(entries)} players in the response.")
            return None
    else:
        print("Failed to retrieve data.")
        print("Status Code:", response.status_code)
        return None

@dataclass
class MessageData:
    author: str
    content: str
    channel: str
    is_mod: bool

class Bot(commands.Bot):

    def __init__(self):
        # Initialise our Bot with our access token, prefix and a list of channels to join on boot...
        # prefix can be a callable, which returns a list of strings or a string...
        # initial_channels can also be a callable which returns a list of strings...
        super().__init__(token='s5jya8kkfqhfobh1kwj8h94zjaqv1q', prefix='!', initial_channels=['guanweiboy'])
        self.author_names = []
        self.last_announcement_time = 0
        self.cooldown_period = 90  # Cooldown period in seconds


        self.conn = sqlite3.connect('global_cooldown.db')
        self.cursor = self.conn.cursor()
        # 建立資料表，儲存命令的全局冷卻時間
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS global_cooldown (
                command_name TEXT,
                last_used REAL,
                PRIMARY KEY (command_name)
            )
        ''')
        self.conn.commit()


    def check_and_update_cooldown(self, command_name: str, cooldown: int):
        """
        檢查冷卻時間是否已過，並更新冷卻時間。
        :param command_name: 指令名稱
        :param cooldown: 冷卻時間（秒）
        :return: 剩餘冷卻時間（如果冷卻中）或 None
        """
        current_time = time.time()
        self.cursor.execute('SELECT last_used FROM global_cooldown WHERE command_name = ?', (command_name,))
        result = self.cursor.fetchone()

        if result:
            last_used = result[0]
            if current_time - last_used < cooldown:
                return cooldown - (current_time - last_used)

        # 更新冷卻時間
        self.cursor.execute('''
            INSERT INTO global_cooldown (command_name, last_used)
            VALUES (?, ?)
            ON CONFLICT(command_name) DO UPDATE SET last_used = excluded.last_used
        ''', (command_name, current_time))
        self.conn.commit()
        return None
    
    

    async def event_ready(self):
        # Notify us when everything is ready!
        # We are logged in and ready to chat and use commands...
        print("Starting twitchbot.py")
        print(f'Logged in as | {self.nick}')
        print(f'User id is | {self.user_id}')
        #asyncio.create_task(self.check_periodically())

    async def event_message(self, message):
        # Messages with echo set to True are messages sent by the bot...
        # For now we just want to ignore them...
        if message.echo:
            return

        '''
        def chat_announcement(self):
            current_time = time.time()
            if current_time - self.last_announcement_time < self.cooldown_period:
                return

            url = 'https://api.twitch.tv/helix/chat/announcements'
            params = {
                'broadcaster_id': '150989534',
                'moderator_id': '653847938'
            }
            headers = {
                'Authorization': 'Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q',
                'Client-Id': 'gp762nuuoqcoxypju8c569th9wz7q5',
                'Content-Type': 'application/json'
            }
            data = {
                'message': 'imGlitch 本台嚴厲斥責任何形式之惡意言論，聊天室言論及抖內發言皆不代表本台主之立場。This channel of Guanweiboy strongly condemns any form of malicious and inappropriate speech. Statements made in the chat and through donations DO NOT represent the views of the channel owner.⚠️ ⚠️ ',
                'color': 'purple'
            }

            response = requests.post(url, headers=headers, params=params, json=data)

            if response.status_code == 204:
                print('Announcement sent successfully!')
                self.last_announcement_time = time.time()
                return(response)
            else:
                print(f'Failed to send announcement: {response.status_code}')
                print(response.json())

        if message.content == "嚴厲斥責":
            chat_announcement(self)
        '''
         
        def chat_announcement2(self):
            current_time = time.time()
            if current_time - self.last_announcement_time < self.cooldown_period:
                return

            def get_channel_info():
                url = f'https://api.twitch.tv/helix/channels?broadcaster_id=150989534'
                headers = {
                    'Authorization': 'Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q',
                    'Client-Id': 'gp762nuuoqcoxypju8c569th9wz7q5'
                }

                response = requests.get(url, headers=headers)

                if response.status_code == 200:
                    data = response.json()
                    title = [item['title'] for item in data['data']]
                    game = [item['game_name'] for item in data['data']]
                    return(title, game)
                else:
                    print(f'Failed to retrieve channel info: {response.status_code}')
                    return None
            channel_info = get_channel_info()
            if channel_info:
                for title, game in zip(channel_info[0], channel_info[1]):
                    title = title
                    game = game

            url = 'https://api.twitch.tv/helix/chat/announcements'
            params = {
                'broadcaster_id': '150989534',
                'moderator_id': '653847938'
            }
            headers = {
                'Authorization': 'Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q',
                'Client-Id': 'gp762nuuoqcoxypju8c569th9wz7q5',
                'Content-Type': 'application/json'
            }
            data = {
                'message': f'imGlitch 🎬實況標題: {title} || 🎮正在遊玩: {game}',
                'color': 'green'
            }

            response = requests.post(url, headers=headers, params=params, json=data)

            if response.status_code == 204:
                print('Announcement sent successfully!')
                self.last_announcement_time = time.time()
                return(response)
            else:
                print(f'Failed to send announcement: {response.status_code}')
                print(response.json())

        def contains_keyword(string, keyword):
            return any(keyword in string for keyword in keywords)

        keywords = ["遊戲叫什麼","遊戲叫甚麼","遊戲的名字","!title"]
        if contains_keyword(message.content, keywords):
            chat_announcement2(self)

        print(message.author.name,':',message.content)

        self.author_names.append(message.author.name)

        def timeout(id):
            broadcaster_id = "150989534"
            moderator_id = "653847938"
            user_id = id
            duration = 600
            reason = "Potential spamming (excuted by lavendertree's bot)"

            headers = {
                "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
                "Authorization": "Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q",
                "Content-Type": "application/json"
            }

            url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

            json_data = {
            'data': {
                'user_id': user_id,
                'duration': duration,
                'reason': reason
                }
            }
            json_payload = json.dumps(json_data)
            response = requests.post(url, headers=headers, data=json_payload)

        def check_if_live(username):
            try:
                response = requests.get(f"https://twitch.tv/{username}")
                response.raise_for_status()
                source_code = response.text

                if "isLiveBroadcast" in source_code:
                    return 1
                else:
                    return 0
            except requests.exceptions.RequestException as error:
                print("Error occurred:", error)


        if len(self.author_names) >= 6 and self.author_names[-1] == self.author_names[-2] == self.author_names[-3] and check_if_live("guanweiboy") == 1:
            if message.author.name == 'Nightbot' or message.author.name == 'guanweiboy':
                pass
            elif self.author_names[-1] == self.author_names[-2] == self.author_names[-3] == self.author_names[-4]:
                pass
            elif self.author_names[-1] == self.author_names[-2] == self.author_names[-3] == self.author_names[-4] == self.author_names[-5]:
                pass
            elif self.author_names[-1] == self.author_names[-2] == self.author_names[-3] == self.author_names[-4] == self.author_names[-5] == self.author_names[-6]:
                pass
            elif message.author.is_mod == 1:
                pass
            elif message.author.is_vip == 1:
                pass
            elif message.author.is_mod == 0:
                if message.author.name == 'q89675851':
                    await bot.connected_channels[0].send(f'@{message.author.name} 此用戶持有三行pass，免除禁言處分 guanwe1Mao6')
                else:
                    await bot.connected_channels[0].send(f'@{message.author.name} cmonBruh 偵測到三行，請節制發言 👉🏿👈🏿')
                    timeout(message.author.id)

        await self.handle_commands(message)
        return message.author.name


    @commands.command()
    async def apex(self, ctx: commands.Context):

        cooldown = 21  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('apex', cooldown)

        if remaining_time:
            return
    
        await ctx.reply(f'點擊觀看冠緯Apex爆殺四名頂獵 guanwe1Bang https://www.youtube.com/watch?v=mZNc3zHd-XQ&t=52s&pp=ygUL5Yag57evIGFwZXg%3D')

    @commands.command()
    async def Apex(self, ctx: commands.Context):

        cooldown = 21  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('apex', cooldown)

        if remaining_time:
            return
    
        await ctx.reply(f'點擊觀看冠緯Apex爆殺四名頂獵 guanwe1Bang https://www.youtube.com/watch?v=mZNc3zHd-XQ&t=52s&pp=ygUL5Yag57evIGFwZXg%3D')

    @commands.command(name='600')
    async def vanish(self, ctx):
        broadcaster_id = "150989534"
        moderator_id = "653847938"
        user_id = ctx.author.id
        duration = 600
        reason = "They wanna timeout themselves"

        headers = {
            "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
            "Authorization": "Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q",
            "Content-Type": "application/json"
        }

        url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

        json_data = {
        'data': {
            'user_id': user_id,
            'duration': duration,
            'reason': reason
            }
        }
        json_payload = json.dumps(json_data)
        response = requests.post(url, headers=headers, data=json_payload)


        respond_list = ['想冷靜一下0..0', '覺得刀子很利，自ban了 guanwe1789 ', 'See u in 600 seconds!']

        if response.status_code == 200:
            await ctx.send(f" @{ctx.author.name} {random.choice(respond_list)}")
        else:
            print(response.text)
            await ctx.send(f" @{ctx.author.name} ban不了你QAQ")

    @commands.command(name='抽')
    async def vanishPOT(self, ctx):
        broadcaster_id = "150989534"
        moderator_id = "653847938"  
        user_id = ctx.author.id  

        cooldown = 6  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('抽', cooldown)

        if remaining_time:
            return

        # 定義禁言時間及其對應的權重
        timeout_options = [10,69, 487, 1212]  # 禁言時間（秒）
        weights = [0.5, 0.25, 0.15, 0.1]  # 對應的機率，加總需為 1

        # 隨機選擇禁言時間
        duration = random.choices(timeout_options, weights)[0]

        reason = "They wanna timeout themselves" 

        headers = {
            "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
            "Authorization": "Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q",
            "Content-Type": "application/json"
        }

        url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

        json_data = {
            'data': {
                'user_id': user_id,
                'duration': duration,  
                'reason': reason  
            }
        }
        json_payload = json.dumps(json_data)
        response = requests.post(url, headers=headers, data=json_payload)

        if response.status_code == 200:  # Twitch API 成功回傳狀態
            if duration == 1212:
                await ctx.send(f"恭喜 @{ctx.author.name} 抽中大獎，禁言1212秒！")
            else:
                pass
        else:
            pass


    @commands.command(name='6OO')
    async def vanish2(self, ctx):
        broadcaster_id = "150989534"
        moderator_id = "653847938"
        user_id = ctx.author.id
        duration = 600
        reason = "They wanna timeout themselves"

        headers = {
            "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
            "Authorization": "Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q",
            "Content-Type": "application/json"
        }

        url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

        json_data = {
        'data': {
            'user_id': user_id,
            'duration': duration,
            'reason': reason
            }
        }
        json_payload = json.dumps(json_data)
        response = requests.post(url, headers=headers, data=json_payload)


        if response.status_code == 200:
            await ctx.send(f" @{ctx.author.name} 以為打OO就不會被ban SUBprise SUBprise ")


    @commands.command(name='600 ')
    async def vanish3(self, ctx):
        broadcaster_id = "150989534"
        moderator_id = "653847938"
        user_id = ctx.author.id
        duration = 600
        reason = "They wanna timeout themselves"

        headers = {
            "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
            "Authorization": "Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q",
            "Content-Type": "application/json"
        }

        url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

        json_data = {
        'data': {
            'user_id': user_id,
            'duration': duration,
            'reason': reason
            }
        }
        json_payload = json.dumps(json_data)
        response = requests.post(url, headers=headers, data=json_payload)


        if response.status_code == 200:
            await ctx.send(f" @{ctx.author.name} 以為加了空格就不會被ban SUBprise SUBprise ")


    @commands.command(name='6᱐᱐')
    async def vanish4(self, ctx):
        broadcaster_id = "150989534"
        moderator_id = "653847938"
        user_id = ctx.author.id
        duration = 600
        reason = "They wanna timeout themselves"

        headers = {
            "Client-Id": 'gp762nuuoqcoxypju8c569th9wz7q5',
            "Authorization": "Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q",
            "Content-Type": "application/json"
        }

        url = f"https://api.twitch.tv/helix/moderation/bans?broadcaster_id={broadcaster_id}&moderator_id={moderator_id}"

        json_data = {
        'data': {
            'user_id': user_id,
            'duration': duration,
            'reason': reason
            }
        }
        json_payload = json.dumps(json_data)
        response = requests.post(url, headers=headers, data=json_payload)


        if response.status_code == 200:
            await ctx.send(f" @{ctx.author.name} 以為換字體就不會被ban SUBprise SUBprise ")

    @commands.command(name='工商')
    async def commercial(self, ctx: commands.Context):
        cooldown = 15  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('COM', cooldown)

        if remaining_time:
            return
        await ctx.reply(f'專屬下載連結: https://tap.io/QGAjJcN guanwe1Mao6 ')        

    @commands.command(name='伊瑟')
    async def commercial2(self, ctx: commands.Context):
        cooldown = 15  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('COM', cooldown)

        if remaining_time:
            return
        await ctx.reply(f'專屬下載連結: https://tap.io/QGAjJcN guanwe1Mao6 ')

    @commands.command()
    async def please(self, ctx: commands.Context):
        await ctx.send(f' @{ctx.author.name} 懇求的臉 🥺🥺🥺🥺🥺')

    @commands.command(name='vr')
    async def vpoints(self, ctx: commands.Context):
        cooldown = 6  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('valorant', cooldown)

        if remaining_time:
            return
        url = "https://splendid-groovy-feverfew.glitch.me/valorant/ap/%E5%86%A0%E7%B7%AF%E5%90%8C%E5%AD%B82/tw2?mmrChange=true"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
        }

        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            await ctx.send(f'@{ctx.author.name} {response.text}')
    
    @commands.command(name='分數')
    async def points(self, ctx: commands.Context):
        point = rank()
        winrate= "{:.1f}".format(float((point[3]/(point[3]+point[4]))*100))
        output = str(f'@{ctx.author.name} 韓服即時分數 :\nVveiR#777 :{point[0]} {point[1]} {point[2]}分, 當前賽季勝率:{winrate}%')
        await ctx.send(output)

    @commands.command(name='r')
    async def rpoints(self, ctx: commands.Context):
        cooldown = 6  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('r', cooldown)

        if remaining_time:
            return
        point = rank()
        winrate= "{:.1f}".format(float((point[3]/(point[3]+point[4]))*100))
        output = str(f'韓服即時分數 :\nVveiR#777 :{point[0]} {point[1]} {point[2]}分, 當前賽季勝率:{winrate}%')
        await ctx.reply(output)

    @commands.command(name='rk')
    async def rrpoints(self, ctx: commands.Context):
        point = rank()
        winrate= "{:.1f}".format(float((point[3]/(point[3]+point[4]))*100))
        output = str(f'韓服即時分數 :\nVveiR#777 :{point[0]} {point[1]} {point[2]}分, 當前賽季勝率:{winrate}%')
        await ctx.reply(output)

    @commands.command(name='RK')
    async def rrrpoints(self, ctx: commands.Context):
        point = rank()
        winrate= "{:.1f}".format(float((point[3]/(point[3]+point[4]))*100))
        output = str(f'韓服即時分數 :\nVveiR#777 :{point[0]} {point[1]} {point[2]}分, 當前賽季勝率:{winrate}%')
        await ctx.reply(output)       

    @commands.command(name='牌位')
    async def rpointss(self, ctx: commands.Context):
        point = rank()
        winrate= "{:.1f}".format(float((point[3]/(point[3]+point[4]))*100))
        output = str(f'韓服即時分數 :\nVveiR#777 :{point[0]} {point[1]} {point[2]}分, 當前賽季勝率:{winrate}%')
        await ctx.reply(output)

    @commands.command(name='rank')
    async def rpointsss(self, ctx: commands.Context):
        point = rank()
        winrate= "{:.1f}".format(float((point[3]/(point[3]+point[4]))*100))
        output = str(f'韓服即時分數 :\nVveiR#777 :{point[0]} {point[1]} {point[2]}分, 當前賽季勝率:{winrate}%')
        await ctx.reply(output)

    @commands.command(name='排位')
    async def rpointssss(self, ctx: commands.Context):
        point = rank()
        winrate= "{:.1f}".format(float((point[3]/(point[3]+point[4]))*100))
        output = str(f'韓服即時分數 :\nVveiR#777 :{point[0]} {point[1]} {point[2]}分, 當前賽季勝率:{winrate}%')
        await ctx.reply(output)

    @commands.command(name='R')
    async def Rpointss(self, ctx: commands.Context):
        point = rank()
        winrate= "{:.1f}".format(float((point[3]/(point[3]+point[4]))*100))
        output = str(f'韓服即時分數 :\nVveiR#777 :{point[0]} {point[1]} {point[2]}分, 當前賽季勝率:{winrate}%')
        await ctx.reply(output)
    


    @commands.command(name='歌單')
    async def playlist(self, ctx: commands.Context):
        await ctx.reply(f'guanwe1Maomao https://www.youtube.com/@lavendertree-ouo/playlists')

    @commands.command(name='songlist')
    async def playlist2(self, ctx: commands.Context):
        await ctx.reply(f'guanwe1Maomao https://www.youtube.com/@lavendertree-ouo/playlists')

    @commands.command(name='動漫')
    async def anime(self, ctx: commands.Context):
        await ctx.reply(f'主播看的動漫不超過十部，動漫推薦請參考這位實況主 https://youtu.be/hdpfAvJ_kTE?si=_FKcRZpBt5ys20ER')


    @commands.command(name='骰子')
    async def dice(self, ctx: commands.Context):
        def weighted_roll(sides, weights):
            """
            Rolls a weighted die and returns one of the sides based on the specified weights.

            :param sides: A list of the sides of the die.
            :param weights: A list of weights corresponding to the probability of each side.
            :return: A side of the die.
            """
            if len(sides) != len(weights):
                raise ValueError("Sides and weights must be of the same length.")

            total_weight = sum(weights)
            rnd = random.uniform(0, total_weight)
            upto = 0
            for side, weight in zip(sides, weights):
                if upto + weight >= rnd:
                    return side
                upto += weight

        sides = [1, 2, 3, 4, 5, 6]
        weights = [1, 1, 1, 1, 1, 1]
        results = weighted_roll(sides, weights)
        output = results
        if ctx.author.is_mod == 1:
            await ctx.send(f'🎲 骰子丟出...結果為：{output}！')

    @commands.command(name='冠貓')
    async def meow(self, ctx: commands.Context):

        def check_if_live(username):
            try:
                response = requests.get(f"https://twitch.tv/{username}")
                response.raise_for_status()
                source_code = response.text

                if "isLiveBroadcast" in source_code:
                    return 1
                else:
                    return 0
            except requests.exceptions.RequestException as error:
                print("Error occurred:", error)

        url = 'https://api.twitch.tv/helix/chat/chatters'
        headers = {
            'Authorization': 'Bearer s5jya8kkfqhfobh1kwj8h94zjaqv1q',
            'Client-Id': 'gp762nuuoqcoxypju8c569th9wz7q5'
        }
        params = {
            'broadcaster_id': '150989534',
            'moderator_id': '653847938'
        }

        response = requests.get(url, headers=headers, params=params)

        if response.status_code == 200 and check_if_live("guanweiboy") == 0:
            data = response.json()
            total = data.get('total', 0)
        else:
            print('Failed to retrieve data:', response.status_code, response.text)

        await ctx.send(f' @{ctx.author.name} 包含你，有{total}隻死忠冠貓在聊天室喵 guanwe1Mao6')

    #運勢指令冷卻資料庫

    def init_db():
        conn = sqlite3.connect("fortune.db")  # 建立或連接資料庫
        cursor = conn.cursor()
        # 建立表格（如果不存在）
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS command_usage (
            user_id TEXT NOT NULL,
            command_name TEXT NOT NULL,
            last_executed TIMESTAMP NOT NULL,
            PRIMARY KEY (user_id, command_name)
        )
        """)
        conn.commit()
        conn.close()
    
    init_db()  # 初始化資料庫
    
    
    @commands.command(name='運勢')
    async def fortune(self, ctx: commands.Context):
        cooldown = 12  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('運勢', cooldown)
        if remaining_time:
            return
        
        fort = ['大吉','中吉','小吉','末吉','凶']
        big = ['天時地利人和，萬事皆能順心如意','無論前進還是停下，都能感受到充滿力量的支持','陽光普照，所有事物都在朝著好的方向發展','內外皆和諧，任何挑戰都能輕鬆迎刃而解','運勢鼎盛，一切都能迎來圓滿的結果','財運亨通，投資或決策皆能獲得豐厚回報','適合開啟新旅程，無論生活還是事業皆能發光發熱']
        mid = ['平穩中帶有上升的氣息，耐心耕耘必有回報','雖然不驚艷，但整體局勢令人感到安心愉快','穩中求進，環境雖未達最佳，但仍有光明可循','雲淡風輕，偶有微風助力，適合穩步前進','運勢逐漸好轉，保持節奏即可迎接美好的變化','雖無大運降臨，但也無災禍，保持節奏即可穩步前進','機會逐漸浮現，只要努力，便能迎來佳績']
        small = ['時有小福降臨，但仍需腳踏實地，持續努力','局勢略顯波動，但整體方向仍是良好的','偶有阻礙，但每個挑戰都帶來新的可能性','運氣尚可，不宜急功近利，穩健是最佳策略','稍縱即逝的小幸運出現，留心細節便能抓住機會','機會雖然存在，但需耐心等待合適時機再行動','雖然有些挑戰，但若能堅持，仍能獲得進展']
        tiny = ['運勢偏弱，但保持冷靜與謹慎仍能穩步向前','現階段需要耐心等待，時機尚未完全成熟','環境略有阻礙，但只要適應節奏即可逐漸改善','表面看似平靜，實則潛藏波折，需時刻注意動態','進展緩慢，但細心經營仍有希望看到成果','短期內難有突破，需耐心等待轉機的到來']
        bad = ['風雨交加，需多加防範，避免冒然行動','低潮時期，保持內心的穩定是最重要的','步履維艱，當下宜以謹慎和耐心為先','暗藏危機，需避免過度樂觀，切勿心存僥倖','外部環境不穩，適宜縮減行動，靜待時局明朗','行動前需再三確認，以免因粗心而造成更大損失']    
        color = ['紅','亮紅','橘紅','橙','陽光黃','黃綠','森林綠','藍','天藍','海洋藍','紫','薰衣草紫','水藍','黑','白','小倪黃','一件黑','好嫩好白','蒂芬妮綠','棕','草綠','連世橙','愛馬仕橘']
        cat = ['guanwe1Mao6','guanwe1Mao1','guanwe1Mao2','guanwe1Nerd','guanwe1Gugu','guanwe1Shy','guanwe1Mao','guanwe1GOOD']
        goodto = ['打LOL','告白','翹課','自助旅行','檢舉世誠','檢舉羅傑','抖內','買樂透','買刮刮樂','抖影片','用歐付寶說話','嘲笑逼寶','玩撲克','在女實況主YT影片留言','訂閱冠緯','跟團旅行','投資','靜','讀書','讀paper']
        notto = ['打LOL','告白','看實況','呼吸','生存','去樓頂放風','低頭看手機','交易股票','交易虛擬貨幣','賭博下注','偷滑主','帶辣條去上班','在fb分享網紅影片','訂閱世誠','爬山','玩水','標記']
        
        def can_execute_command(user_id, command_name):
            conn = sqlite3.connect("fortune.db")
            cursor = conn.cursor()
            
            # 查詢用戶的指令執行時間
            cursor.execute("""
            SELECT last_executed FROM command_usage
            WHERE user_id = ? AND command_name = ?
            """, (user_id, command_name))
            result = cursor.fetchone()
            
            current_time = datetime.now()
            current_date = current_time.date()  # 只取日期部分
            
            if result:
                last_executed = datetime.fromisoformat(result[0])
                last_date = last_executed.date()  # 只取上次執行的日期部分
                # 檢查是否為同一天
                if current_date == last_date:
                    conn.close()
                    return False  # 同一天，不允許執行
            
            # 更新或插入執行時間
            cursor.execute("""
            INSERT OR REPLACE INTO command_usage (user_id, command_name, last_executed)
            VALUES (?, ?, ?)
            """, (user_id, command_name, current_time.isoformat()))
            conn.commit()
            conn.close()
            return True  # 允許執行
        
        user_id = ctx.author.name
        command_name = "運勢"
        
        fcat = random.choice(cat)
        fcolor = random.choice(color)
        result_fortune = random.choice(fort)
        fgoodto = random.choice(goodto)
        fnotto = random.choice(notto)
        
        if result_fortune == '大吉':
            name = '大吉'
            result = random.choice(big)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 宜：{fgoodto} | 幸運色：{fcolor} | 幸運貓： {fcat}')
            else:
                await ctx.reply(f'請明天再來!')
        elif result_fortune == '中吉':
            name = '中吉'
            result = random.choice(mid)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 宜：{fgoodto} | 幸運色：{fcolor} | 幸運貓： {fcat}')
            else:
                await ctx.reply(f'請明天再來!')
        elif result_fortune == '小吉':
            name = '小吉'
            result = random.choice(small)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 宜：{fgoodto} | 幸運色：{fcolor} | 幸運貓： {fcat}')
            else:
                await ctx.reply(f'請明天再來!')
        elif result_fortune == '末吉':
            name = '末吉'
            result = random.choice(tiny)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 不宜：{fnotto} | 幸運色：{fcolor} | 幸運貓： {fcat}')
            else:
                await ctx.reply(f'請明天再來!')
        elif result_fortune == '凶':
            name = '凶'
            result = random.choice(bad)
            if can_execute_command(user_id, command_name):
                await ctx.reply(f'guanwe1888 您的今日運勢為：{name} | {result}, 不宜：{fnotto} | 幸運色：{fcolor} | 幸運貓： {fcat}')
            else:
                await ctx.reply(f'請明天再來!')

    @commands.command(name='玩什麼')
    async def play(self, ctx: commands.Context):
        cooldown = 15  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('玩什麼', cooldown)

        if remaining_time:
            return

        games = [
            "英雄聯盟", "LOL", "League of Legends", "steam只逛不買", "哩跟歐甫咧捐", "韓服英雄聯盟",
            "台服英雄聯盟", "陸服英雄聯盟", "日服英雄聯盟", "poker", "戶外台", "魔物獵人", "跑跑",
            "Apex", "陪玩只看不點", "楓之谷", "瀏覽Live頻道"
        ]
        cgame = random.choice(games)
        output = str(f'@{ctx.author.name} {cgame} guanwe1Bangbang')
        await ctx.send(output)

    @commands.command(name='吃什麼')
    async def eat(self, ctx: commands.Context):
        cooldown = 15  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('吃什麼', cooldown)

        if remaining_time:
            return

        foods = [
            "牛肉麵", "水餃", "飯糰", "炒飯", "炒麵", "乾麵", "湯麵", "湯餃", "滷肉飯", "雞肉飯", 
            "雞魯飯", "肉羹麵", "魚酥羹麵", "辣炒年糕", "部隊鍋", "韓式起司拉麵", 
            "拉麵", "壽喜燒", "丼飯", "壽司", "火鍋", "燒烤", "海底撈", "義大利麵", "法式料理", 
            "三明治", "便利商店", "地瓜球", "排骨湯", "麥當勞", "肯德基", "漢堡王", "熱炒", 
            "雞排", "麵包", "鍋燒意麵", "烤肉飯", "水果", "沙拉", "餅乾", "自助餐", "披薩", "牛排"
        ]
        cfood = random.choice(foods)
        output = str(f'@{ctx.author.name} {cfood} guanwe1Bangbang')
        await ctx.send(output)

    food_index = 0  # 全局變數來記錄目前的索引

    @commands.command(name='jar')
    async def boss(self, ctx: commands.Context):
        cooldown = 15  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('boss', cooldown)

        if remaining_time:
            return

        foods = ['訂閱者Verified GZjar: 我很想待在這裡，但實在是太無聊了','SubscriberVerifiedGZjar: 你可能会赠送20个订阅，但关伟永远是我的 !!!!!!',
                 'SubscriberVerifiedGZjar: 关伟是个男孩，他不是一个男人','訂閱者Verified GZjar: 你为什么在吃鸡？你需要对新手才能感觉强大吗???','訂閱者已驗證GZjar: 你是要玩游戏还是只会一直说些没用的？'
                 ,'SubscriberVerifiedGZjar: 冠緯是我爸爸，但幸運的是我沒有遺傳到他的身高基因。我高得不可思議','SubscriberVerifiedGZjar: 我觉得这个主播说太多话，没专注在游戏上','戴上那副太陽眼鏡，你看起來像個毒販'
        ]

        output = f'@{ctx.author.name} {foods[self.food_index]}'
        
        await ctx.send(output)  # 發送訊息
        
        self.food_index += 1  # 移動到下一個訊息
        if self.food_index >= len(foods):  # 如果到最後一個，就從頭開始
            self.food_index = 0

    @commands.command(name='冠貓塔')
    async def tower(self, ctx: commands.Context): 
        cooldown = 90  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('冠貓塔', cooldown)

        if remaining_time:
            return
        await ctx.send('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ guanwe1Mao6 ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ guanwe1Mao6 guanwe1Mao6 ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ guanwe1Mao6 guanwe1Mao6 guanwe1Mao6 ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ guanwe1Mao6 guanwe1Mao6 guanwe1Mao6 guanwe1Mao6 ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ guanwe1Mao6 guanwe1Mao6 guanwe1Mao6 guanwe1Mao6 guanwe1Mao6')


    from typing import Optional

    @commands.command(name='level')
    async def level123(self, ctx: commands.Context):
        cooldown = 10  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('等級', cooldown)

        if remaining_time:
            return

        import sqlite3

        def get_user_data(user_id=None, user_name=None):
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                
                # 根据 user_id 或 user_name 查询用户数据
                if user_id:
                    cursor.execute('SELECT score, count, total FROM users WHERE user_id = ?', (user_id,))
                elif user_name:
                    cursor.execute('SELECT score, count, total FROM users WHERE user_name = ?', (user_name,))
                else:
                    return None, None, None
                
                result = cursor.fetchone()
                if result:
                    return result  # 返回 score, count, total
                else:
                    return None, None, None

        def get_user_rank(user_id=None, excluded_ids=None):
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                
                if excluded_ids:
                    query = '''
                        SELECT user_id, total 
                        FROM users 
                        WHERE user_id NOT IN ({}) 
                        ORDER BY total DESC
                    '''.format(','.join(['?'] * len(excluded_ids)))
                    cursor.execute(query, excluded_ids)
                else:
                    cursor.execute('SELECT user_id, total FROM users ORDER BY total DESC')

                all_users = cursor.fetchall()

                for rank, (u_id, total) in enumerate(all_users, start=1):
                    if user_id and u_id == user_id:
                        return rank, total
                return None, None

        def get_user_pr_rank(user_id):
            query = '''
                WITH user_stats AS (
                    SELECT 
                        total,
                        (SELECT COUNT(*) FROM users WHERE total > u.total) * 100.0 / 
                        (SELECT COUNT(*) FROM users) AS pr_percentage
                    FROM users u
                    WHERE user_id = ?
                )
                SELECT pr_percentage 
                FROM user_stats
            '''
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                cursor.execute(query, (user_id,))
                result = cursor.fetchone()
                if result:
                    return round(result[0], 3)
                return None

        def read_avg_from_file(path='avg_result.json'):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get("avg_top_3_percent")
            except (FileNotFoundError, json.JSONDecodeError):
                return None

        avg_value = read_avg_from_file()
        
        def classify_by_percentage(percentage, count):
            if percentage <= 1 and count > avg_value:
                return '宗師冠貓'
            elif percentage <= 1:
                return '大師冠貓'
            elif percentage <= 10:
                return '鑽石冠貓'
            elif percentage <= 20:
                return '白金冠貓'
            elif percentage <= 35:
                return '黃金冠貓'
            elif percentage <= 50:
                return '白銀冠貓'
            elif percentage <= 60:
                return '青銅冠貓'
            else:
                return '簡單貓'


        user_id = ctx.author.id

        score, count, total = get_user_data(user_id=user_id)
        rank, total = get_user_rank(user_id=user_id, excluded_ids=['19264788', '653847938'])
        pr = get_user_pr_rank(user_id=user_id)

        
        if score is not None and count is not None:
            if rank <= 20:
                await ctx.reply(f"guanwe1Gan 總積分--{total} 階級--菁英冠貓#{rank} ({pr}%). 聊天數:{count} | 共觀看:{score * 0.25} hr")
            else:
                await ctx.reply(f"guanwe1Gan 總積分--{total} 階級--{classify_by_percentage(pr, count)} #{rank} ({pr}%). 聊天數:{count} | 共觀看:{score * 0.25} hr")

    @commands.command(name='level123')
    async def level(self, ctx: commands.Context):

        cooldown = 20  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('等級1', cooldown)

        if remaining_time:
            return

        output = str(f'@{ctx.author.name} 月排行重置,資料收集中...嘗試 !history or !award 查看歷史排名')
        await ctx.send(output)

    @commands.command(name='history')
    async def history(self, ctx: commands.Context):

        cooldown = 10  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('history', cooldown)

        if remaining_time:
            return

        import sqlite3

        # 連接 3月資料庫
        def march(user_id):
            conn_march = sqlite3.connect("march.db")
            cursor_march = conn_march.cursor()

            cursor_march.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_march.fetchone()
            conn_march.close()
            if result:
                return result
            else:
                return ("N", "無資料")

        # 連接 4月資料庫
        def april(user_id):
            conn_april = sqlite3.connect("april.db")
            cursor_april = conn_april.cursor()

            cursor_april.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_april.fetchone()
            conn_april.close()
            if result:
                return result
            else:
                return ("N", "無資料")
        
        # 連接 5月資料庫
        def may(user_id):
            conn_may = sqlite3.connect("may.db")
            cursor_may = conn_may.cursor()

            cursor_may.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_may.fetchone()
            conn_may.close()
            if result:
                return result
            else:
                return ("N", "無資料")

        # 連接 6月資料庫
        def june(user_id):
            conn_june = sqlite3.connect("june.db")
            cursor_june = conn_june.cursor()

            cursor_june.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_june.fetchone()
            conn_june.close()
            if result:
                return result
            else:
                return ("N", "無資料")
        
        # 連接 7月資料庫
        def july(user_id):
            conn_july = sqlite3.connect("july.db")
            cursor_july = conn_july.cursor()

            cursor_july.execute("SELECT rank, title FROM ranked_result WHERE user_id = ?", (user_id,))
            result = cursor_july.fetchone()
            conn_july.close()
            if result:
                return result
            else:
                return ("N", "無資料")

        user_id = ctx.author.id

        march_result = march(user_id)
        april_result = april(user_id)
        may_result = may(user_id)
        june_result = june(user_id)
        july_result = july(user_id)  

        if user_id == '152701250': #minglee
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #1 [發言王] | 4月:菁英冠貓 #1 [發言王] | 5月:菁英冠貓 #1 [發言王] | 6月:菁英冠貓 #2 | 7月:菁英冠貓 #1 [發言王]")
        elif user_id == '147080444': #斑斑
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #4 [掛台王] | 4月:菁英冠貓 #4 [掛台王] | 5月:宗師冠貓 #21 | 6月:宗師冠貓 #21 | 7月:大師冠貓 #23")
        elif user_id == '109499201': #冠緯一貓六
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #2 | 4月:菁英冠貓 #2 [守靈幫主] | 5月:菁英冠貓 #2 [守靈幫主] | 6月:菁英冠貓 #3 [守靈幫主] | 7月:菁英冠貓 #2")
        elif user_id == '93228342': #XDD
            await ctx.reply(f"歷史冠貓榜排行 - 3月:大師冠貓 #205 | 4月:鑽石冠貓 #2492 | 5月:鑽石冠貓 #926 [標記幫主] | 6月:鑽石冠貓 #1135 | 7月:白金冠貓 #3164")
        elif user_id == '28212434': #班長
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #5 | 4月:菁英冠貓 #7 | 5月:菁英冠貓 #8 [掛台王] | 6月:菁英冠貓 #12 | 7月:菁英冠貓 #7 [掛台王]")
        elif user_id == '643304176': #yukaikyu
            await ctx.reply(f"歷史冠貓榜排行 - 3月:鑽石冠貓 #624 | 4月:大師冠貓 #144 | 5月:大師冠貓 #52 | 6月:菁英冠貓 #1 [發言王] | 7月:大師冠貓 #193")
        elif user_id == '695807373': #熊貓狗_叉滴
            await ctx.reply(f"歷史冠貓榜排行 - 3月:菁英冠貓 #11 | 4月:菁英冠貓 #6 | 5月:菁英冠貓 #6 | 6月:菁英冠貓 #8 [掛台王] | 7月:菁英冠貓 #8")
        else:
            await ctx.reply(f"歷史冠貓榜排行 - 3月:{march_result[1]} #{march_result[0]} | 4月:{april_result[1]} #{april_result[0]} | 5月:{may_result[1]} #{may_result[0]} | 6月:{june_result[1]} #{june_result[0]} | 7月:{july_result[1]} #{july_result[0]}")

    @commands.command(name='levelfor')
    async def levelfor(self, ctx: commands.Context, user_name: Optional[str] = None):
        cooldown = 10  
        remaining_time = self.check_and_update_cooldown('等級2', cooldown)

        if remaining_time:
            return

        import sqlite3

        def get_user_data(user_id=None, user_name=None):
            """获取指定用户的 score、count 和 total"""
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                
                if user_id:
                    cursor.execute('SELECT score, count, total FROM users WHERE user_id = ?', (user_id,))
                elif user_name:
                    cursor.execute('SELECT score, count, total FROM users WHERE user_name = ?', (user_name,))
                else:
                    return None, None, None
                
                result = cursor.fetchone()
                if result:
                    return result  # 返回 score, count, total
                else:
                    return None, None, None

        def get_user_rank(user_id=None, excluded_ids=None):
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                
                if excluded_ids:
                    query = '''
                        SELECT user_id, total 
                        FROM users 
                        WHERE user_id NOT IN ({}) 
                        ORDER BY total DESC
                    '''.format(','.join(['?'] * len(excluded_ids)))
                    cursor.execute(query, excluded_ids)
                else:
                    cursor.execute('SELECT user_id, total FROM users ORDER BY total DESC')

                all_users = cursor.fetchall()

                for rank, (u_id, total) in enumerate(all_users, start=1):
                    if user_id and u_id == user_id:
                        return rank, total
                return None, None

        def get_user_pr_rank(user_id):
            query = '''
                WITH user_stats AS (
                    SELECT 
                        total,
                        (SELECT COUNT(*) FROM users WHERE total > u.total) * 100.0 / 
                        (SELECT COUNT(*) FROM users) AS pr_percentage
                    FROM users u
                    WHERE user_id = ?
                )
                SELECT pr_percentage 
                FROM user_stats
            '''
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                cursor.execute(query, (user_id,))
                result = cursor.fetchone()
                if result:
                    return round(result[0], 3)
                return None

        def read_avg_from_file(path='avg_result.json'):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get("avg_top_3_percent")
            except (FileNotFoundError, json.JSONDecodeError):
                return None

        avg_value = read_avg_from_file()

        def classify_by_percentage(percentage, count):
            if percentage <= 1 and count > avg_value:
                return '宗師冠貓'
            elif percentage <= 1:
                return '大師冠貓'
            elif percentage <= 10:
                return '鑽石冠貓'
            elif percentage <= 20:
                return '白金冠貓'
            elif percentage <= 35:
                return '黃金冠貓'
            elif percentage <= 50:
                return '白銀冠貓'
            elif percentage <= 60:
                return '青銅冠貓'
            else:
                return '簡單貓'

        if user_name:
            with sqlite3.connect('userslevel.db') as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT user_id FROM users WHERE user_name = ?', (user_name,))
                user_id = cursor.fetchone()
                if user_id:
                    user_id = user_id[0]
                else:
                    return
        else:
            user_id = ctx.author.id

        score, count, total = get_user_data(user_id=user_id)
        rank, total = get_user_rank(user_id=user_id, excluded_ids=['19264788', '653847938'])
        pr = get_user_pr_rank(user_id=user_id)

        
        if score is not None and count is not None:
            if user_name:  
                if rank <= 20:
                    await ctx.reply(f"{user_name} 的數據: 總積分--{total} 階級--菁英冠貓 #{rank} 聊天數:{count} | 共觀看:{score * 0.25} hr")
                else:
                    await ctx.reply(f"{user_name} 的數據: 總積分--{total} 階級--{classify_by_percentage(pr, count)} #{rank} 聊天數:{count} | 共觀看:{score * 0.25} hr")
            else: 
                if rank <= 20:
                    await ctx.reply(f"guanwe1Gan 總積分--{total} 階級--菁英冠貓 #{rank} ({pr}%) 聊天數:{count} | 共觀看:{score * 0.25} hr")
                else:
                    await ctx.reply(f"guanwe1Gan 總積分--{total} 階級--{classify_by_percentage(pr, count)} #{rank} ({pr}%) 聊天數:{count} | 共觀看:{score * 0.25} hr")
        else:
            await ctx.reply(f"查無此用戶，請嘗試使用顯示ID(非純英數ID)")

    @commands.command(name='top10')
    async def top10(self, ctx: commands.Context):
        cooldown = 35  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('top10', cooldown)

        if remaining_time:
            return
        
        rank_labels = ["1st", "2nd", "3rd"] + [f"{i}th" for i in range(4, 11)]  # 定義排名格式
        formatted_top_users = []
        skip_users = {"Nightbot","阿倫同學"}
        
        try:
            # 連接資料庫
            conn = sqlite3.connect("userslevel.db")
            cursor = conn.cursor()
            
            # 查詢前十名用戶（根據你的需求排序，這裡假設以 total 降序排序）
            query = "SELECT user_name FROM users ORDER BY total DESC LIMIT 12"
            cursor.execute(query)
            results = cursor.fetchall()
            
            # 遍歷結果，跳過 "Nightbot"，只記錄前十名
            count = 0
            for user_name, in results:
                if user_name in skip_users:
                    continue  
                
                formatted_top_users.append(f"{rank_labels[count]}: {user_name}")
                count += 1
                
                if count == 10:  # 只記錄前十名
                    break
            
            conn.close()
        except Exception as e:
            print(f"資料庫操作失敗: {e}")

        formatted_top_users = [s.replace("你哥2", "urbro2") for s in formatted_top_users]
        await ctx.reply(f'guanwe1Nerd 魯蛇排行---{" ".join(formatted_top_users)}')

    @commands.command(name='award')
    async def award(self, ctx: commands.Context):

        cooldown = 20  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('award', cooldown)

        if remaining_time:
            return

        output = str('7月各項數據前三名:[聊天數]🥇 MingLee_XD 🥈 冠緯1貓6 🥉 拉薩今谷維 [掛台時數] 🥇 比爾班長 🥈 熊貓狗_叉滴 🥉 是我辣 [標記率] -> !標記幫')
        await ctx.reply(output)

    @commands.command(name='標記幫')
    async def taggang(self, ctx: commands.Context):

        cooldown = 20  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('taggang', cooldown)

        if remaining_time:
            return

        output = str('7月標記率排行:1st-大東亞地區周杰倫分倫-33.7% , 2nd-正久-31.2% , 3rd-布拉德特羅爾5-22.8% , 4th-鮮奶茶加珍珠-20.3% , 5th-桀哥母湯-19.3% , 6th-拉機圖奇-18.8% , 7th-一毛一-18.5% , 8th-RickyIol-18.4% , 9th-bernieyo-17.4% , 10th-哇系大星-16.1%')
        await ctx.reply(output)


    @commands.command(name='這場有誰4444')
    async def player(self, ctx: commands.Context):
        cooldown = 45  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('這場有誰', cooldown)

        if remaining_time:
            return

        await ctx.send('資料爬取中，請稍候 xdd1Loading ')

        # 設定瀏覽器選項（可選）
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.page_load_strategy = "eager"
        prefs = {
            "profile.managed_default_content_settings.images": 2,
            "profile.managed_default_content_settings.stylesheets": 2,
            "profile.managed_default_content_settings.fonts": 2,
            "profile.managed_default_content_settings.plugins": 2
        }
        chrome_options.add_experimental_option("prefs", prefs)

        # 設定 ChromeDriver 路徑
        service = Service("C:/chromedriver.exe")  # 替換為你的 chromedriver 路徑

        # 啟動 WebDriver
        driver = webdriver.Chrome(service=service, options=chrome_options)

        # 爬取網站完整 HTML 程式碼
        url = "https://www.deeplol.gg/summoner/kr/%EC%9C%8C%EB%A6%AC%EC%97%84-9919/ingame"
        try:
            driver.get(url)
            # 2. 明確等待關鍵元素出現
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, "influ-name"))
            )

            # 3. 限制最大捲動次數，並在找到目標元素後提前結束
            for _ in range(5):
                driver.execute_script("window.scrollBy(0, document.body.scrollHeight);")
                time.sleep(1)
                if driver.find_elements(By.CLASS_NAME, "influ-name"):
                    break

            # 4. 直接在記憶體拿 HTML
            html = driver.page_source

        finally:
            driver.quit()

        # 5. 用正則一次抓所有索引
        blue_positions = [m.start() for m in re.finditer("藍", html)]
        red_positions  = [m.start() for m in re.finditer("紅", html)]
        matches        = [m.start() for m in re.finditer("influ-name", html)]

        blue_team, red_team, streamer, pro = [], [], [], []

        for idx in matches:
            # 6. 取出 >…< 之間的文字
            start = html.find(">", idx)
            end   = html.find("<", start)
            if start == -1 or end == -1:
                continue
            name = html[start+1:end].strip()

            # 7. 判斷屬於哪一隊
            nb = max((p for p in blue_positions if p < idx), default=-1)
            nr = max((p for p in red_positions  if p < idx), default=-1)
            if nb > nr:
                blue_team.append(name)
            else:
                red_team.append(name)

            # 8. 判斷 streamer / pro
            snippet = html[idx: idx+200]
            if "strm" in snippet:
                streamer.append(name)
            if "pro" in snippet:
                pro.append(name)

        # 9. 組字串並回傳
        output_blue = " | ".join(blue_team)
        output_red  = " | ".join(red_team[1:])
        
        await ctx.reply(f'藍方：{output_blue} , 紅方：{output_red}')

    @commands.command(name='開台機率')
    async def streamodds(self, ctx: commands.Context):
        cooldown = 60  # 冷卻時間（秒）
        remaining_time = self.check_and_update_cooldown('streamodds', cooldown)

        if remaining_time:
            return
        def estimate_stream_prob_v3(day3, day2, day1, has_sponsor, now=None):
            if has_sponsor == 1:
                return 100.0

            if now is None:
                now = datetime.now()

            base_score = 50
            penalty = day3 * 10 + day2 * 15 + day1 * 25
            bonus_rest = 20 if day3 + day2 + day1 == 0 else 0
            total_minutes = now.hour * 60 + now.minute
            time_bonus = ((1440 - total_minutes) / 1440) * 20
            is_weekend = now.weekday() in [5, 6]
            weekend_bonus = 10 if is_weekend else 0
            random_offset = random.uniform(-1, 0.3)

            final_score = base_score - penalty + bonus_rest + time_bonus + weekend_bonus + random_offset
            return round(max(min(final_score, 100), 1), 1)
        
        def check_if_live(username):
            try:
                response = requests.get(f"https://twitch.tv/{username}")
                response.raise_for_status()
                source_code = response.text

                if "isLiveBroadcast" in source_code:
                    return 1
                else:
                    return 0
            except requests.exceptions.RequestException as error:
                print("Error occurred:", error)

        # === 掛載 Google Sheets ===
        gc = pygsheets.authorize(service_account_file='client_secret_131219573855-ae6i2htfffg07fbsld9vphqr41u4v9cl.apps.googleusercontent.com.json')        
        url = 'https://docs.google.com/spreadsheets/d/11aNVYLlKuOBEfz0EUFdTFrLfMoubJCyJpQedbysQ6JI/edit?gid=0#gid=0'
        sh = gc.open_by_url(url)
        ws = sh.worksheet_by_title('工作表1')

        # === 讀取資料（跳過標題列）===

        day3 = int(ws.get_value('A2'))
        day2 = int(ws.get_value('B2'))
        day1 = int(ws.get_value('C2'))
        has_sponsor = int(ws.get_value('D2'))

        score = estimate_stream_prob_v3(day3, day2, day1, has_sponsor)
        #print(score)
        if check_if_live("guanweiboy") == 0:
            await ctx.reply(f'今天的開台機率為：{str(score)}%!')

bot = Bot()
bot.run()

